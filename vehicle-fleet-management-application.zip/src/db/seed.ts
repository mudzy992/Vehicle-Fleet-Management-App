import "dotenv/config";
import { db } from "./index";
import {
  vehicles,
  drivers,
  registrations,
  services,
  maintenancePlans,
  trips,
  locations,
  fuelLogs,
} from "./schema";
import { sql } from "drizzle-orm";

function d(offsetDays: number): string {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

function ts(offsetDays: number, hour = 9): Date {
  const date = new Date();
  date.setDate(date.getDate() + offsetDays);
  date.setHours(hour, 0, 0, 0);
  return date;
}

async function seed() {
  console.log("Brisanje postojećih podataka...");
  await db.execute(sql`TRUNCATE TABLE fuel_logs, locations, trips, maintenance_plans, services, registrations, drivers, vehicles RESTART IDENTITY CASCADE`);

  console.log("Ubacivanje vozila...");
  const v = await db
    .insert(vehicles)
    .values([
      { naziv: "Passat B8 — Službeni", marka: "Volkswagen", model: "Passat 2.0 TDI", tip: "limuzina", godiste: 2021, registracionaOznaka: "BG 214-KS", brojSasije: "WVWZZZ3CZME061234", gorivo: "dizel", status: "aktivno", kilometraza: 86540, datumNabavke: "2021-05-14", nabavnaCijena: "34500", boja: "Crna" },
      { naziv: "Octavia — Terenska", marka: "Škoda", model: "Octavia 2.0 TDI", tip: "limuzina", godiste: 2022, registracionaOznaka: "BG 883-PM", brojSasije: "TMBAA9NX4N5012455", gorivo: "dizel", status: "aktivno", kilometraza: 45210, datumNabavke: "2022-03-02", nabavnaCijena: "27900", boja: "Siva" },
      { naziv: "Tiguan — Menadžment", marka: "Volkswagen", model: "Tiguan 2.0 TDI 4Motion", tip: "suv", godiste: 2023, registracionaOznaka: "NS 452-TG", brojSasije: "WVGZZZ5NZPW314521", gorivo: "dizel", status: "aktivno", kilometraza: 21300, datumNabavke: "2023-01-20", nabavnaCijena: "44200", boja: "Bijela" },
      { naziv: "Sprinter — Dostava", marka: "Mercedes-Benz", model: "Sprinter 316 CDI", tip: "kombi", godiste: 2020, registracionaOznaka: "BG 991-DV", brojSasije: "WDB9066331S288445", gorivo: "dizel", status: "servis", kilometraza: 168920, datumNabavke: "2020-09-10", nabavnaCijena: "39800", boja: "Bijela" },
      { naziv: "Golf 8 eHybrid", marka: "Volkswagen", model: "Golf 8 eHybrid", tip: "limuzina", godiste: 2023, registracionaOznaka: "SA 330-EV", brojSasije: "WVWZZZCDZPW674321", gorivo: "hibrid", status: "aktivno", kilometraza: 12760, datumNabavke: "2023-06-15", nabavnaCijena: "36100", boja: "Plava" },
      { naziv: "Crafter — Logistika", marka: "Volkswagen", model: "Crafter 2.0 TDI L3H3", tip: "kombi", godiste: 2019, registracionaOznaka: "PG 118-LG", brojSasije: "WV1ZZZSYZK9063214", gorivo: "dizel", status: "aktivno", kilometraza: 221400, datumNabavke: "2019-11-05", nabavnaCijena: "33500", boja: "Siva" },
      { naziv: "Octavia Scout", marka: "Škoda", model: "Octavia Scout 4x4", tip: "suv", godiste: 2021, registracionaOznaka: "BG 560-MR", brojSasije: "TMBKF9NX6M4011552", gorivo: "dizel", status: "aktivno", kilometraza: 98450, datumNabavke: "2021-08-24", nabavnaCijena: "31700", boja: "Zelena" },
      { naziv: "Caddy — Tehnička", marka: "Volkswagen", model: "Caddy Cargo 2.0 TDI", tip: "kombi", godiste: 2024, registracionaOznaka: "NS 774-TH", brojSasije: "WV2ZZZSKZRX095512", gorivo: "dizel", status: "neaktivno", kilometraza: 3120, datumNabavke: "2024-02-01", nabavnaCijena: "28900", boja: "Narandžasta" },
    ])
    .returning();

  console.log("Ubacivanje vozača...");
  const dr = await db
    .insert(drivers)
    .values([
      { ime: "Marko", prezime: "Petrović", email: "marko.petrovic@flota.rs", telefon: "+381 64 123 4567", brojVozacke: "RS-8823142", kategorije: "B, C", vozackaVaziDo: d(185), status: "aktivan", datumZaposlenja: "2019-03-01" },
      { ime: "Jelena", prezime: "Simić", email: "jelena.simic@flota.rs", telefon: "+381 63 555 0182", brojVozacke: "RS-7712045", kategorije: "B", vozackaVaziDo: d(24), status: "aktivan", datumZaposlenja: "2021-06-15" },
      { ime: "Nikola", prezime: "Jovanović", email: "nikola.jovanovic@flota.rs", telefon: "+387 65 998 311", brojVozacke: "BA-3350211", kategorije: "B, C, E", vozackaVaziDo: d(402), status: "aktivan", datumZaposlenja: "2018-01-22" },
      { ime: "Ivana", prezime: "Kovačević", email: "ivana.kovacevic@flota.rs", telefon: "+381 65 402 7781", brojVozacke: "RS-6618573", kategorije: "B", vozackaVaziDo: d(310), status: "odmor", datumZaposlenja: "2020-10-05" },
      { ime: "Stefan", prezime: "Đorđević", email: "stefan.djordjevic@flota.rs", telefon: "+382 67 441 209", brojVozacke: "ME-2094317", kategorije: "B, C", vozackaVaziDo: d(-11), status: "aktivan", datumZaposlenja: "2017-04-12" },
      { ime: "Milica", prezime: "Stojanović", email: "milica.stojanovic@flota.rs", telefon: "+385 98 223 6901", brojVozacke: "HR-5509823", kategorije: "B", vozackaVaziDo: d(96), status: "aktivan", datumZaposlenja: "2022-09-19" },
    ])
    .returning();

  console.log("Ubacivanje registracija...");
  await db.insert(registrations).values([
    { vehicleId: v[0].id, datumRegistracije: d(-330), vaziDo: d(35), brojPolice: "POL-2024-88214", osiguravajucaKuca: "Dunav Osiguranje", iznos: "48200", placeno: true },
    { vehicleId: v[1].id, datumRegistracije: d(-360), vaziDo: d(5), brojPolice: "POL-2024-71390", osiguravajucaKuca: "Generali", iznos: "41500", placeno: true },
    { vehicleId: v[2].id, datumRegistracije: d(-190), vaziDo: d(175), brojPolice: "POL-2024-98104", osiguravajucaKuca: "DDOR", iznos: "52300", placeno: true },
    { vehicleId: v[3].id, datumRegistracije: d(-352), vaziDo: d(13), brojPolice: "POL-2024-60233", osiguravajucaKuca: "Triglav", iznos: "61800", placeno: false },
    { vehicleId: v[4].id, datumRegistracije: d(-150), vaziDo: d(215), brojPolice: "POL-2024-44771", osiguravajucaKuca: "Grawe", iznos: "44900", placeno: true },
    { vehicleId: v[5].id, datumRegistracije: d(-380), vaziDo: d(-15), brojPolice: "POL-2023-51908", osiguravajucaKuca: "Lovćen", iznos: "58200", placeno: true },
    { vehicleId: v[6].id, datumRegistracije: d(-300), vaziDo: d(65), brojPolice: "POL-2024-38150", osiguravajucaKuca: "Dunav Osiguranje", iznos: "46700", placeno: true },
    { vehicleId: v[7].id, datumRegistracije: d(-90), vaziDo: d(275), brojPolice: "POL-2024-29413", osiguravajucaKuca: "DDOR", iznos: "39400", placeno: true },
  ]);

  console.log("Ubacivanje servisa...");
  await db.insert(services).values([
    { vehicleId: v[0].id, tip: "mali_servis", naziv: "Mali servis — ulje i filteri", opis: "Zamjena ulja 5W-30, filter ulja, filter kabine.", serviser: "AutoCentar Stanić", datum: d(-75), kilometraza: 82100, iznos: "32000", status: "zavrsen", sledeciServisKm: 97100, sledeciServisDatum: d(120) },
    { vehicleId: v[3].id, tip: "popravka", naziv: "Zamjena kvačila", opis: "Set kvačila, pomoćni valjak, radni sati.", serviser: "MB Servis Lukić", datum: d(4), kilometraza: 168920, iznos: "148000", status: "u_toku", sledeciServisKm: 181000, sledeciServisDatum: d(140) },
    { vehicleId: v[2].id, tip: "gume", naziv: "Zimske gume 235/55 R18", opis: "4 x gume, balansiranje, centriranje.", serviser: "Vulkanizer Pro", datum: d(12), kilometraza: 21300, iznos: "86000", status: "zakazan" },
    { vehicleId: v[5].id, tip: "veliki_servis", naziv: "Veliki servis — 220.000 km", opis: "Zupčasti remen, vodena pumpa, kočnice, rashladna tečnost.", serviser: "VW Oldtimer Smederevo", datum: d(-158), kilometraza: 218000, iznos: "196000", status: "zavrsen", sledeciServisKm: 233000, sledeciServisDatum: d(90) },
    { vehicleId: v[4].id, tip: "mali_servis", naziv: "Prvi servis eHybrid", opis: "Pregled akumulatora, softversko ažuriranje.", serviser: "VW Sarajevo", datum: d(-30), kilometraza: 11800, iznos: "18500", status: "zavrsen", sledeciServisKm: 26800, sledeciServisDatum: d(300) },
    { vehicleId: v[6].id, tip: "mali_servis", naziv: "Zamjena ulja i filtera", opis: "Ulje, filteri, pregled kočnica.", serviser: "Škoda servis BG", datum: d(-52), kilometraza: 95100, iznos: "29800", status: "zavrsen", sledeciServisKm: 110100, sledeciServisDatum: d(150) },
    { vehicleId: v[1].id, tip: "registracija_radovi", naziv: "Tehnički pregled priprema", opis: "Pregled svjetala i amortizera prije registracije.", serviser: "AMSS Vozdovac", datum: d(2), kilometraza: 45210, iznos: "9500", status: "zakazan" },
  ] as never);

  console.log("Ubacivanje plana održavanja...");
  await db.insert(maintenancePlans).values([
    { vehicleId: v[0].id, naslov: "Zamjena ulja i filtera", intervalKm: 15000, intervalDana: 365, zadnjeIzvrseno: d(-75), zadnjeIzvrsenoKm: 82100, status: "predstoji" },
    { vehicleId: v[0].id, naslov: "Kočiona tečnost", intervalKm: null, intervalDana: 730, zadnjeIzvrseno: d(-410), zadnjeIzvrsenoKm: 58000, status: "isteklo" },
    { vehicleId: v[1].id, naslov: "Zamjena ulja i filtera", intervalKm: 15000, intervalDana: 365, zadnjeIzvrseno: d(-290), zadnjeIzvrsenoKm: 31200, status: "zakazano" },
    { vehicleId: v[2].id, naslov: "Rotacija guma", intervalKm: 10000, intervalDana: null, zadnjeIzvrseno: d(-160), zadnjeIzvrsenoKm: 11200, status: "predstoji" },
    { vehicleId: v[3].id, naslov: "Servis klima uređaja", intervalKm: null, intervalDana: 365, zadnjeIzvrseno: d(-400), zadnjeIzvrsenoKm: 149000, status: "isteklo" },
    { vehicleId: v[5].id, naslov: "Zamjena zupčastog remena", intervalKm: 120000, intervalDana: 1825, zadnjeIzvrseno: d(-158), zadnjeIzvrsenoKm: 218000, status: "uradjeno" },
    { vehicleId: v[6].id, naslov: "Zamjena ulja i filtera", intervalKm: 15000, intervalDana: 365, zadnjeIzvrseno: d(-52), zadnjeIzvrsenoKm: 95100, status: "predstoji" },
  ]);

  console.log("Ubacivanje putnih naloga...");
  await db.insert(trips).values([
    { brojNaloga: "PN-2025-0148", vehicleId: v[0].id, driverId: dr[0].id, polaziste: "Beograd", odrediste: "Novi Sad", svrha: "Sastanak sa klijentom", datumPolaska: ts(-2, 8), datumDolaska: ts(-2, 18), status: "zavrsen", predjenoKm: 196, pocetnaKilometraza: 86344, zavrsnaKilometraza: 86540, troskovi: "4200" },
    { brojNaloga: "PN-2025-0149", vehicleId: v[2].id, driverId: dr[1].id, polaziste: "Beograd", odrediste: "Zagreb", svrha: "Sajam ambijentala", datumPolaska: ts(-1, 6), datumDolaska: ts(1, 20), status: "u_toku", predjenoKm: 0, pocetnaKilometraza: 21300, troskovi: "12000" },
    { brojNaloga: "PN-2025-0150", vehicleId: v[3].id, driverId: dr[2].id, polaziste: "Beograd", odrediste: "Sarajevo", svrha: "Isporuka robe — 12 paketa", datumPolaska: ts(3, 7), status: "planiran", predjenoKm: 0, troskovi: "9500" },
    { brojNaloga: "PN-2025-0143", vehicleId: v[5].id, driverId: dr[4].id, polaziste: "Podgorica", odrediste: "Bar", svrha: "Transport opreme", datumPolaska: ts(-12, 9), datumDolaska: ts(-12, 17), status: "zavrsen", predjenoKm: 118, pocetnaKilometraza: 221282, zavrsnaKilometraza: 221400, troskovi: "3100" },
    { brojNaloga: "PN-2025-0144", vehicleId: v[4].id, driverId: dr[5].id, polaziste: "Sarajevo", odrediste: "Mostar", svrha: "Servisna posjeta klijentu", datumPolaska: ts(-9, 10), datumDolaska: ts(-9, 19), status: "zavrsen", predjenoKm: 258, pocetnaKilometraza: 12502, zavrsnaKilometraza: 12760, troskovi: "5400" },
    { brojNaloga: "PN-2025-0145", vehicleId: v[1].id, driverId: dr[3].id, polaziste: "Beograd", odrediste: "Niš", svrha: "Edukacija tima", datumPolaska: ts(-6, 8), datumDolaska: ts(-6, 21), status: "zavrsen", predjenoKm: 474, pocetnaKilometraza: 44736, zavrsnaKilometraza: 45210, troskovi: "8300" },
    { brojNaloga: "PN-2025-0151", vehicleId: v[6].id, driverId: dr[0].id, polaziste: "Beograd", odrediste: "Budimpešta", svrha: "Preuzimanje opreme", datumPolaska: ts(2, 5), status: "planiran", predjenoKm: 0, troskovi: "22000" },
    { brojNaloga: "PN-2025-0152", vehicleId: v[2].id, driverId: dr[4].id, polaziste: "Novi Sad", odrediste: "Subotica", svrha: "Terenski pregled", datumPolaska: ts(5, 9), status: "planiran", predjenoKm: 0, troskovi: "2800" },
    { brojNaloga: "PN-2025-0146", vehicleId: v[0].id, driverId: dr[5].id, polaziste: "Beograd", odrediste: "Krusedol", svrha: "Team building", datumPolaska: ts(-4, 7), datumDolaska: ts(-4, 23), status: "zavrsen", predjenoKm: 172, pocetnaKilometraza: 86172, zavrsnaKilometraza: 86344, troskovi: "3900" },
    { brojNaloga: "PN-2025-0147", vehicleId: v[5].id, driverId: dr[2].id, polaziste: "Beograd", odrediste: "Kolašin", svrha: "Zimska logistika", datumPolaska: ts(-3, 6), datumDolaska: ts(-1, 19), status: "otkazan", predjenoKm: 0, troskovi: "0", napomena: "Otkazano zbog vremenskih uslova." },
  ] as never);

  console.log("Ubacivanje lokacija...");
  const cityCoords: Record<string, [number, number]> = {
    Beograd: [44.7866, 20.4489],
    "Novi Sad": [45.2671, 19.8335],
    Niš: [43.3209, 21.8958],
    Zagreb: [45.815, 15.9819],
    Sarajevo: [43.8563, 18.4131],
    Podgorica: [42.4304, 19.2594],
    Mostar: [43.3438, 17.8078],
  };
  const locs = [
    { vehicleId: v[0].id, grad: "Beograd", adresa: "Bulevar Mihajla Pupina 165, Beograd", brzina: 0 },
    { vehicleId: v[1].id, grad: "Beograd", adresa: "Auto-put E75, Voždovac", brzina: 82 },
    { vehicleId: v[2].id, grad: "Zagreb", adresa: "A3 Zagreb — Lipovac", brzina: 118 },
    { vehicleId: v[3].id, grad: "Novi Sad", adresa: "MB Servis Lukić, Novi Sad", brzina: 0 },
    { vehicleId: v[4].id, grad: "Sarajevo", adresa: "Bulevar Meše Selimovića 88", brzina: 44 },
    { vehicleId: v[5].id, grad: "Podgorica", adresa: "Josipa Broza Tita 12", brzina: 0 },
    { vehicleId: v[6].id, grad: "Niš", adresa: "Bulevar Nemanjića 44", brzina: 56 },
    { vehicleId: v[7].id, grad: "Beograd", adresa: "Magacin 3, Zemun", brzina: 0 },
  ];
  for (const l of locs) {
    const [baseLat, baseLng] = cityCoords[l.grad];
    for (let i = 0; i < 7; i++) {
      await db.insert(locations).values({
        vehicleId: l.vehicleId,
        lat: (baseLat + (Math.random() - 0.5) * 0.16 * (i / 7)).toFixed(6),
        lng: (baseLng + (Math.random() - 0.5) * 0.16 * (i / 7)).toFixed(6),
        adresa: l.adresa,
        brzina: i === 6 ? l.brzina : Math.floor(Math.random() * 90),
        zapisaоAt: new Date(Date.now() - (6 - i) * 1000 * 60 * 42),
      } as never);
    }
  }

  console.log("Ubacivanje goriva...");
  for (const veh of v) {
    let liters = 41;
    for (let i = 8; i >= 0; i--) {
      const l = Math.round((liters + Math.random() * 18) * 10) / 10;
      const price = 1.72 + Math.random() * 0.22;
      await db.insert(fuelLogs).values({
        vehicleId: veh.id,
        datum: d(-i * 11 - Math.floor(Math.random() * 4)),
        litara: l.toFixed(2),
        cijenaPoLitri: price.toFixed(2),
        ukupanIznos: (l * price * 120).toFixed(0),
        kilometraza: Math.max(1000, veh.kilometraza - i * 900),
        pumpa: ["NIS Petrol", "OMV", "Eko", "INA", "Petrol BH"][Math.floor(Math.random() * 5)],
      });
    }
  }

  console.log("Seed završen!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed greška:", err);
  process.exit(1);
});

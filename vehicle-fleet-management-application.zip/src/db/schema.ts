import { relations } from "drizzle-orm";
import {
  pgTable,
  pgEnum,
  serial,
  varchar,
  text,
  integer,
  numeric,
  date,
  timestamp,
  boolean,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

export const vehicleStatusEnum = pgEnum("vehicle_status", [
  "aktivno",
  "servis",
  "neaktivno",
]);

export const fuelTypeEnum = pgEnum("fuel_type", [
  "dizel",
  "benzin",
  "hibrid",
  "elektricno",
  "gas",
]);

export const vehicleTypeEnum = pgEnum("vehicle_type", [
  "limuzina",
  "suv",
  "kombi",
  "kamion",
]);

export const driverStatusEnum = pgEnum("driver_status", [
  "aktivan",
  "odmor",
  "neaktivan",
]);

export const serviceTypeEnum = pgEnum("service_type", [
  "mali_servis",
  "veliki_servis",
  "popravka",
  "gume",
  "registracija_radovi",
  "ostalo",
]);

export const serviceStatusEnum = pgEnum("service_status", [
  "zakazan",
  "u_toku",
  "zavrsen",
]);

export const tripStatusEnum = pgEnum("trip_status", [
  "planiran",
  "u_toku",
  "zavrsen",
  "otkazan",
]);

export const maintenanceStatusEnum = pgEnum("maintenance_status", [
  "predstoji",
  "zakazano",
  "uradjeno",
  "isteklo",
]);

// ---------------------------------------------------------------------------
// VOZILA (vehicles)
// ---------------------------------------------------------------------------

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  naziv: varchar("naziv", { length: 120 }).notNull(),
  marka: varchar("marka", { length: 60 }).notNull(),
  model: varchar("model", { length: 60 }).notNull(),
  tip: vehicleTypeEnum("tip").notNull().default("limuzina"),
  godiste: integer("godiste").notNull(),
  registracionaOznaka: varchar("registraciona_oznaka", { length: 20 })
    .notNull()
    .unique(),
  brojSasije: varchar("broj_sasije", { length: 40 }).notNull().unique(),
  gorivo: fuelTypeEnum("gorivo").notNull().default("dizel"),
  status: vehicleStatusEnum("status").notNull().default("aktivno"),
  kilometraza: integer("kilometraza").notNull().default(0),
  datumNabavke: date("datum_nabavke"),
  nabavnaCijena: numeric("nabavna_cijena", { precision: 12, scale: 2 }),
  boja: varchar("boja", { length: 30 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// VOZAČI (drivers)
// ---------------------------------------------------------------------------

export const drivers = pgTable("drivers", {
  id: serial("id").primaryKey(),
  ime: varchar("ime", { length: 60 }).notNull(),
  prezime: varchar("prezime", { length: 60 }).notNull(),
  email: varchar("email", { length: 120 }).notNull().unique(),
  telefon: varchar("telefon", { length: 30 }).notNull(),
  brojVozacke: varchar("broj_vozacke", { length: 30 }).notNull().unique(),
  kategorije: varchar("kategorije", { length: 20 }).notNull().default("B"),
  vozackaVaziDo: date("vozacka_vazi_do").notNull(),
  status: driverStatusEnum("status").notNull().default("aktivan"),
  datumZaposlenja: date("datum_zaposlenja"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// REGISTRACIJE (registrations)
// ---------------------------------------------------------------------------

export const registrations = pgTable("registrations", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "cascade" }),
  datumRegistracije: date("datum_registracije").notNull(),
  vaziDo: date("vazi_do").notNull(),
  brojPolice: varchar("broj_police", { length: 40 }),
  osiguravajucaKuca: varchar("osiguravajuca_kuca", { length: 120 }),
  iznos: numeric("iznos", { precision: 10, scale: 2 }).notNull().default("0"),
  placeno: boolean("placeno").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// SERVISI (services)
// ---------------------------------------------------------------------------

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "cascade" }),
  tip: serviceTypeEnum("tip").notNull().default("mali_servis"),
  naziv: varchar("naziv", { length: 160 }).notNull(),
  opis: text("opis"),
  serviser: varchar("serviser", { length: 120 }),
  datum: date("datum").notNull(),
  kilometraza: integer("kilometraza"),
  iznos: numeric("iznos", { precision: 10, scale: 2 }).notNull().default("0"),
  status: serviceStatusEnum("status").notNull().default("zakazan"),
  sledeciServisKm: integer("sledeci_servis_km"),
  sledeciServisDatum: date("sledeci_servis_datum"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// PLAN ODRŽAVANJA (maintenance plans)
// ---------------------------------------------------------------------------

export const maintenancePlans = pgTable("maintenance_plans", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "cascade" }),
  naslov: varchar("naslov", { length: 160 }).notNull(),
  intervalKm: integer("interval_km"),
  intervalDana: integer("interval_dana"),
  zadnjeIzvrseno: date("zadnje_izvrseno"),
  zadnjeIzvrsenoKm: integer("zadnje_izvrseno_km"),
  status: maintenanceStatusEnum("status").notNull().default("predstoji"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// PUTNI NALOZI (trips)
// ---------------------------------------------------------------------------

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  brojNaloga: varchar("broj_naloga", { length: 30 }).notNull().unique(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "restrict" }),
  driverId: integer("driver_id")
    .notNull()
    .references(() => drivers.id, { onDelete: "restrict" }),
  polaziste: varchar("polaziste", { length: 120 }).notNull(),
  odrediste: varchar("odrediste", { length: 120 }).notNull(),
  svrha: varchar("svrha", { length: 200 }),
  datumPolaska: timestamp("datum_polaska", { withTimezone: true }).notNull(),
  datumDolaska: timestamp("datum_dolaska", { withTimezone: true }),
  status: tripStatusEnum("status").notNull().default("planiran"),
  predjenoKm: integer("predjeno_km").notNull().default(0),
  pocetnaKilometraza: integer("pocetna_kilometraza"),
  zavrsnaKilometraza: integer("zavrsna_kilometraza"),
  troskovi: numeric("troskovi", { precision: 10, scale: 2 }).notNull().default("0"),
  napomena: text("napomena"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// LOKACIJE (GPS locations)
// ---------------------------------------------------------------------------

export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "cascade" }),
  lat: numeric("lat", { precision: 10, scale: 6 }).notNull(),
  lng: numeric("lng", { precision: 10, scale: 6 }).notNull(),
  adresa: varchar("adresa", { length: 160 }),
  brzina: integer("brzina").notNull().default(0),
  zapisaоAt: timestamp("zabljeseno_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// GORIVO (fuel logs)
// ---------------------------------------------------------------------------

export const fuelLogs = pgTable("fuel_logs", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id")
    .notNull()
    .references(() => vehicles.id, { onDelete: "cascade" }),
  datum: date("datum").notNull(),
  litara: numeric("litara", { precision: 8, scale: 2 }).notNull(),
  cijenaPoLitri: numeric("cijena_po_litri", { precision: 6, scale: 2 }).notNull(),
  ukupanIznos: numeric("ukupan_iznos", { precision: 10, scale: 2 }).notNull(),
  kilometraza: integer("kilometraza"),
  pumpa: varchar("pumpa", { length: 120 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ---------------------------------------------------------------------------
// RELATIONS
// ---------------------------------------------------------------------------

export const vehiclesRelations = relations(vehicles, ({ many }) => ({
  registrations: many(registrations),
  services: many(services),
  maintenancePlans: many(maintenancePlans),
  trips: many(trips),
  locations: many(locations),
  fuelLogs: many(fuelLogs),
}));

export const driversRelations = relations(drivers, ({ many }) => ({
  trips: many(trips),
}));

export const registrationsRelations = relations(registrations, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [registrations.vehicleId],
    references: [vehicles.id],
  }),
}));

export const servicesRelations = relations(services, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [services.vehicleId],
    references: [vehicles.id],
  }),
}));

export const maintenancePlansRelations = relations(
  maintenancePlans,
  ({ one }) => ({
    vehicle: one(vehicles, {
      fields: [maintenancePlans.vehicleId],
      references: [vehicles.id],
    }),
  }),
);

export const tripsRelations = relations(trips, ({ one }) => ({
  vehicle: one(vehicles, { fields: [trips.vehicleId], references: [vehicles.id] }),
  driver: one(drivers, { fields: [trips.driverId], references: [drivers.id] }),
}));

export const locationsRelations = relations(locations, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [locations.vehicleId],
    references: [vehicles.id],
  }),
}));

export const fuelLogsRelations = relations(fuelLogs, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [fuelLogs.vehicleId],
    references: [vehicles.id],
  }),
}));

// ---------------------------------------------------------------------------
// TIPOVI
// ---------------------------------------------------------------------------

export type Vehicle = typeof vehicles.$inferSelect;
export type Driver = typeof drivers.$inferSelect;
export type Registration = typeof registrations.$inferSelect;
export type Service = typeof services.$inferSelect;
export type MaintenancePlan = typeof maintenancePlans.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type Location = typeof locations.$inferSelect;
export type FuelLog = typeof fuelLogs.$inferSelect;

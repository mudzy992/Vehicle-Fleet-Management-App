"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, Phone, Mail, IdCard, Route, ShieldCheck, UserRound } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { StatusPill } from "@/components/shared/status-pill";
import { useApi } from "@/components/shared/use-api";
import { apiSend } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Skeleton, AvatarCircle } from "@/components/ui/extras";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { formatKm, formatDate, daysUntil, initials, expiryTone } from "@/lib/format";
import { cn } from "@/lib/utils";

type DriverRow = {
  id: number;
  ime: string;
  prezime: string;
  email: string;
  telefon: string;
  brojVozacke: string;
  kategorije: string;
  vozackaVaziDo: string;
  status: string;
  brojNaloga: number;
  predjenoKm: number;
};

const TONES = ["lime", "sky", "amber", "rose", "violet"] as const;

const emptyForm = {
  ime: "", prezime: "", email: "", telefon: "", brojVozacke: "", kategorije: "B", vozackaVaziDo: "",
};

function AddDriverDialog({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const set = (k: keyof typeof emptyForm) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    if (!form.ime || !form.prezime || !form.vozackaVaziDo) {
      toast.error("Ime, prezime i datum isteka dozvole su obavezni");
      return;
    }
    setSaving(true);
    try {
      await apiSend("/api/drivers", "POST", form);
      toast.success("Vozač dodan u sistem");
      setOpen(false);
      setForm(emptyForm);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4" /> Dodaj vozača</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Novi vozač</DialogTitle>
          <DialogDescription>Osnovni podaci za karton vozača.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Ime *</Label>
            <Input value={form.ime} onChange={set("ime")} placeholder="Marko" />
          </div>
          <div className="space-y-1.5">
            <Label>Prezime *</Label>
            <Input value={form.prezime} onChange={set("prezime")} placeholder="Petrović" />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={set("email")} placeholder="ime@flota.rs" />
          </div>
          <div className="space-y-1.5">
            <Label>Telefon</Label>
            <Input value={form.telefon} onChange={set("telefon")} placeholder="+381 64 …" />
          </div>
          <div className="space-y-1.5">
            <Label>Broj vozačke</Label>
            <Input value={form.brojVozacke} onChange={set("brojVozacke")} className="font-mono uppercase" />
          </div>
          <div className="space-y-1.5">
            <Label>Kategorije</Label>
            <Input value={form.kategorije} onChange={set("kategorije")} placeholder="B, C" />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Vozačka vrijedi do *</Label>
            <Input type="date" value={form.vozackaVaziDo} onChange={set("vozackaVaziDo")} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>Otkaži</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Čuvanje…" : "Sačuvaj"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function VozaciPage() {
  const { data, loading, reload } = useApi<DriverRow[]>("/api/drivers", 60000);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Ljudi"
        title="Vozači"
        description={`${data?.length ?? "…"} vozača — dozvole, kategorije i statistika vožnje.`}
        actions={<AddDriverDialog onDone={() => reload(true)} />}
      />

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-64" />)}
        </div>
      ) : !data || data.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-white/10 py-24 text-center text-zinc-500">
          <UserRound className="h-10 w-10 text-zinc-700" />
          Nema evidentiranih vozača.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.map((d, i) => {
            const dani = daysUntil(d.vozackaVaziDo);
            const tone = expiryTone(dani);
            return (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, y: 22 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.05 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                className="group relative overflow-hidden rounded-2xl border border-white/[0.07] bg-zinc-900/60 p-5 transition-all duration-300 hover:border-white/[0.15] hover:-translate-y-0.5"
              >
                <div className="flex items-start gap-4">
                  <AvatarCircle initials={initials(d.ime, d.prezime)} tone={TONES[i % TONES.length]} className="h-14 w-14 text-base" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-lg font-semibold text-white">
                      {d.ime} {d.prezime}
                    </div>
                    <div className="font-mono text-[10px] uppercase tracking-widest text-zinc-500">
                      {d.brojVozacke} • kat. {d.kategorije}
                    </div>
                    <div className="mt-2"><StatusPill status={d.status} /></div>
                  </div>
                </div>

                <div className="mt-5 space-y-2 text-xs text-zinc-400">
                  <div className="flex items-center gap-2.5">
                    <Mail className="h-3.5 w-3.5 text-zinc-600" />
                    <span className="truncate">{d.email}</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Phone className="h-3.5 w-3.5 text-zinc-600" />
                    {d.telefon}
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-2">
                  <div className="rounded-xl bg-white/[0.03] p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-lg font-bold text-white">
                      <Route className="h-4 w-4 text-lime-300" />
                      {d.brojNaloga}
                    </div>
                    <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">naloga</div>
                  </div>
                  <div className="rounded-xl bg-white/[0.03] p-3 text-center">
                    <div className="text-lg font-bold text-white">{formatKm(d.predjenoKm).replace(" km", "")}</div>
                    <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">km pređeno</div>
                  </div>
                </div>

                <div
                  className={cn(
                    "mt-4 flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-medium",
                    tone === "danger" && "bg-red-400/10 text-red-300",
                    tone === "warning" && "bg-amber-400/10 text-amber-300",
                    tone === "ok" && "bg-emerald-400/10 text-emerald-300",
                  )}
                >
                  <span className="flex items-center gap-2">
                    {tone === "ok" ? <ShieldCheck className="h-4 w-4" /> : <IdCard className="h-4 w-4" />}
                    Vozačka dozvola
                  </span>
                  <span className="font-mono">
                    {dani < 0 ? `istekla ${-dani}d` : `${dani}d • ${formatDate(d.vozackaVaziDo)}`}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vehicles, registrations, services, trips } from "@/db/schema";
import { and, asc, eq, ilike, or, sql } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const q = req.nextUrl.searchParams.get("q") ?? "";
    const status = req.nextUrl.searchParams.get("status") ?? "";

    const conds = [];
    if (q) {
      conds.push(
        or(
          ilike(vehicles.naziv, `%${q}%`),
          ilike(vehicles.registracionaOznaka, `%${q}%`),
          ilike(vehicles.marka, `%${q}%`),
          ilike(vehicles.model, `%${q}%`),
        )!,
      );
    }
    if (status) conds.push(eq(vehicles.status, status as never));

    const rows = await db
      .select({
        id: vehicles.id,
        naziv: vehicles.naziv,
        marka: vehicles.marka,
        model: vehicles.model,
        tip: vehicles.tip,
        godiste: vehicles.godiste,
        registracionaOznaka: vehicles.registracionaOznaka,
        gorivo: vehicles.gorivo,
        status: vehicles.status,
        kilometraza: vehicles.kilometraza,
        boja: vehicles.boja,
        regVaziDo: sql<string | null>`(select max(${registrations.vaziDo}) from ${registrations} where ${registrations.vehicleId} = ${vehicles.id})`,
        zadnjiServis: sql<string | null>`(select max(${services.datum}) from ${services} where ${services.vehicleId} = ${vehicles.id} and ${services.status} = 'zavrsen')`,
        sledeciServisKm: sql<number | null>`(select max(${services.sledeciServisKm}) from ${services} where ${services.vehicleId} = ${vehicles.id} and ${services.sledeciServisKm} is not null)`,
        brojNaloga: sql<number>`(select count(*) from ${trips} where ${trips.vehicleId} = ${vehicles.id})::int`,
      })
      .from(vehicles)
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(asc(vehicles.id));

    return NextResponse.json(rows);
  } catch (error) {
    console.error("Vehicles GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju vozila" }, { status: 500 });
  }
}

const vehicleSchema = z.object({
  naziv: z.string().min(2),
  marka: z.string().min(1),
  model: z.string().min(1),
  tip: z.enum(["limuzina", "suv", "kombi", "kamion"]).default("limuzina"),
  godiste: z.coerce.number().int().min(1990).max(2030),
  registracionaOznaka: z.string().min(4),
  brojSasije: z.string().min(6),
  gorivo: z.enum(["dizel", "benzin", "hibrid", "elektricno", "gas"]).default("dizel"),
  kilometraza: z.coerce.number().int().min(0).default(0),
  boja: z.string().optional(),
  datumNabavke: z.string().optional(),
  nabavnaCijena: z.coerce.number().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = vehicleSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "Neispravni podaci" },
        { status: 400 },
      );
    }
    const d = parsed.data;
    const [created] = await db
      .insert(vehicles)
      .values({
        naziv: d.naziv,
        marka: d.marka,
        model: d.model,
        tip: d.tip,
        godiste: d.godiste,
        registracionaOznaka: d.registracionaOznaka.toUpperCase(),
        brojSasije: d.brojSasije.toUpperCase(),
        gorivo: d.gorivo,
        kilometraza: d.kilometraza,
        boja: d.boja ?? null,
        datumNabavke: d.datumNabavke || null,
        nabavnaCijena: d.nabavnaCijena ? String(d.nabavnaCijena) : null,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "";
    if (msg.includes("unique")) {
      return NextResponse.json({ error: "Registraciona oznaka ili šasija već postoji" }, { status: 409 });
    }
    console.error("Vehicles POST error:", error);
    return NextResponse.json({ error: "Greška pri dodavanju vozila" }, { status: 500 });
  }
}

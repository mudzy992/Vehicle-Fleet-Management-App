import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  vehicles,
  registrations,
  services,
  maintenancePlans,
  trips,
  drivers,
  fuelLogs,
  locations,
} from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const vehicleId = Number(id);
    const [vehicle] = await db
      .select()
      .from(vehicles)
      .where(eq(vehicles.id, vehicleId))
      .limit(1);
    if (!vehicle) return NextResponse.json({ error: "Vozilo nije pronađeno" }, { status: 404 });

    const [servisi, registracije, plan, nalozi, gorivo, zadnjaLokacija] = await Promise.all([
      db.select().from(services).where(eq(services.vehicleId, vehicleId)).orderBy(desc(services.datum)),
      db.select().from(registrations).where(eq(registrations.vehicleId, vehicleId)).orderBy(desc(registrations.vaziDo)),
      db.select().from(maintenancePlans).where(eq(maintenancePlans.vehicleId, vehicleId)),
      db
        .select({
          id: trips.id,
          brojNaloga: trips.brojNaloga,
          polaziste: trips.polaziste,
          odrediste: trips.odrediste,
          status: trips.status,
          datumPolaska: trips.datumPolaska,
          predjenoKm: trips.predjenoKm,
          vozacIme: drivers.ime,
          vozacPrezime: drivers.prezime,
        })
        .from(trips)
        .innerJoin(drivers, eq(trips.driverId, drivers.id))
        .where(eq(trips.vehicleId, vehicleId))
        .orderBy(desc(trips.datumPolaska)),
      db.select().from(fuelLogs).where(eq(fuelLogs.vehicleId, vehicleId)).orderBy(desc(fuelLogs.datum)).limit(12),
      db
        .select()
        .from(locations)
        .where(eq(locations.vehicleId, vehicleId))
        .orderBy(desc(locations.zapisaоAt))
        .limit(1),
    ]);

    const [stats] = await db
      .select({
        trosakServisi: sql<number>`coalesce(sum(${services.iznos}::numeric),0)::float`,
        trosakGorivo: sql<number>`0::float`,
      })
      .from(services)
      .where(eq(services.vehicleId, vehicleId));

    const [fuelStats] = await db
      .select({ trosakGorivo: sql<number>`coalesce(sum(${fuelLogs.ukupanIznos}::numeric),0)::float` })
      .from(fuelLogs)
      .where(eq(fuelLogs.vehicleId, vehicleId));

    return NextResponse.json({
      vehicle,
      servisi,
      registracije,
      plan,
      nalozi,
      gorivo,
      lokacija: zadnjaLokacija[0] ?? null,
      trosakServisi: stats.trosakServisi,
      trosakGorivo: fuelStats.trosakGorivo,
    });
  } catch (error) {
    console.error("Vehicle detail error:", error);
    return NextResponse.json({ error: "Greška" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const allowed = [
      "naziv", "kilometraza", "status", "boja", "gorivo", "tip",
    ] as const;
    const updates: Record<string, unknown> = {};
    for (const key of allowed) {
      if (body[key] !== undefined) updates[key] = body[key];
    }
    const [updated] = await db
      .update(vehicles)
      .set(updates)
      .where(eq(vehicles.id, Number(id)))
      .returning();
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Vehicle PATCH error:", error);
    return NextResponse.json({ error: "Greška pri ažuriranju" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    await db.delete(vehicles).where(eq(vehicles.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Vehicle DELETE error:", error);
    return NextResponse.json({ error: "Vozilo ima povezane naloge i ne može se obrisati" }, { status: 409 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { registrations, vehicles } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: registrations.id,
        vehicleId: registrations.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        slikaTip: vehicles.tip,
        datumRegistracije: registrations.datumRegistracije,
        vaziDo: registrations.vaziDo,
        brojPolice: registrations.brojPolice,
        osiguravajucaKuca: registrations.osiguravajucaKuca,
        iznos: registrations.iznos,
        placeno: registrations.placeno,
        danaPreostalo: sql<number>`(${registrations.vaziDo}::date - current_date)::int`,
      })
      .from(registrations)
      .innerJoin(vehicles, eq(registrations.vehicleId, vehicles.id))
      .orderBy(registrations.vaziDo);
    return NextResponse.json(rows);
  } catch (error) {
    console.error("Registrations GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju registracija" }, { status: 500 });
  }
}

const registrationSchema = z.object({
  vehicleId: z.coerce.number().int(),
  datumRegistracije: z.string(),
  vaziDo: z.string(),
  brojPolice: z.string().optional(),
  osiguravajucaKuca: z.string().optional(),
  iznos: z.coerce.number().default(0),
  placeno: z.boolean().default(true),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = registrationSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Neispravni podaci" }, { status: 400 });
    }
    const d = parsed.data;
    const [created] = await db
      .insert(registrations)
      .values({
        vehicleId: d.vehicleId,
        datumRegistracije: d.datumRegistracije,
        vaziDo: d.vaziDo,
        brojPolice: d.brojPolice || null,
        osiguravajucaKuca: d.osiguravajucaKuca || null,
        iznos: String(d.iznos),
        placeno: d.placeno,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Registrations POST error:", error);
    return NextResponse.json({ error: "Greška pri dodavanju registracije" }, { status: 500 });
  }
}

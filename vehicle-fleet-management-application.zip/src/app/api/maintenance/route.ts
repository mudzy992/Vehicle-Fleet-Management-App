import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { maintenancePlans, vehicles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: maintenancePlans.id,
        vehicleId: maintenancePlans.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        trenutnaKm: vehicles.kilometraza,
        naslov: maintenancePlans.naslov,
        intervalKm: maintenancePlans.intervalKm,
        intervalDana: maintenancePlans.intervalDana,
        zadnjeIzvrseno: maintenancePlans.zadnjeIzvrseno,
        zadnjeIzvrsenoKm: maintenancePlans.zadnjeIzvrsenoKm,
        status: maintenancePlans.status,
      })
      .from(maintenancePlans)
      .innerJoin(vehicles, eq(maintenancePlans.vehicleId, vehicles.id))
      .orderBy(maintenancePlans.status, maintenancePlans.id);
    return NextResponse.json(rows);
  } catch (error) {
    console.error("Maintenance GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju plana održavanja" }, { status: 500 });
  }
}

const planSchema = z.object({
  vehicleId: z.coerce.number().int(),
  naslov: z.string().min(2),
  intervalKm: z.coerce.number().int().optional(),
  intervalDana: z.coerce.number().int().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = planSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Neispravni podaci" }, { status: 400 });
    const d = parsed.data;
    const [created] = await db
      .insert(maintenancePlans)
      .values({
        vehicleId: d.vehicleId,
        naslov: d.naslov,
        intervalKm: d.intervalKm ?? null,
        intervalDana: d.intervalDana ?? null,
        status: "predstoji",
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Maintenance POST error:", error);
    return NextResponse.json({ error: "Greška" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status } = body as { id: number; status: string };
    const updates: Record<string, unknown> = { status };
    if (status === "uradjeno") {
      const [plan] = await db.select().from(maintenancePlans).where(eq(maintenancePlans.id, id));
      if (plan) {
        updates.zadnjeIzvrseno = new Date().toISOString().slice(0, 10);
        const [v] = await db.select().from(vehicles).where(eq(vehicles.id, plan.vehicleId));
        updates.zadnjeIzvrsenoKm = v?.kilometraza ?? null;
      }
    }
    const [updated] = await db
      .update(maintenancePlans)
      .set(updates)
      .where(eq(maintenancePlans.id, id))
      .returning();
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Maintenance PATCH error:", error);
    return NextResponse.json({ error: "Greška" }, { status: 500 });
  }
}

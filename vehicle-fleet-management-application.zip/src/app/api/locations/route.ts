import { NextResponse } from "next/server";
import { db } from "@/db";
import { locations, vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const latest = await db
      .selectDistinctOn([locations.vehicleId], {
        vehicleId: locations.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        tip: vehicles.tip,
        status: vehicles.status,
        lat: locations.lat,
        lng: locations.lng,
        adresa: locations.adresa,
        brzina: locations.brzina,
        vrijeme: locations.zapisaоAt,
      })
      .from(locations)
      .innerJoin(vehicles, eq(locations.vehicleId, vehicles.id))
      .orderBy(locations.vehicleId, desc(locations.zapisaоAt));

    const trails = await db
      .select({
        vehicleId: locations.vehicleId,
        lat: locations.lat,
        lng: locations.lng,
        vrijeme: locations.zapisaоAt,
        brzina: locations.brzina,
      })
      .from(locations)
      .orderBy(locations.vehicleId, locations.zapisaоAt);

    return NextResponse.json({ latest, trails });
  } catch (error) {
    console.error("Locations GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju lokacija" }, { status: 500 });
  }
}

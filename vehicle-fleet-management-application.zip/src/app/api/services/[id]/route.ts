import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { services, vehicles } from "@/db/schema";
import { eq } from "drizzle-orm";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const allowed = [
      "tip", "naziv", "opis", "serviser", "datum", "kilometraza",
      "iznos", "status", "sledeciServisKm", "sledeciServisDatum",
    ] as const;
    const updates: Record<string, unknown> = {};
    for (const key of allowed) if (body[key] !== undefined) updates[key] = String(body[key]);
    if (updates.kilometraza !== undefined) updates.kilometraza = Number(updates.kilometraza);

    const [current] = await db.select().from(services).where(eq(services.id, Number(id)));
    const [updated] = await db.update(services).set(updates).where(eq(services.id, Number(id))).returning();
    if (!updated) return NextResponse.json({ error: "Servis nije pronađen" }, { status: 404 });

    if (current && body.status === "zavrsen") {
      await db.update(vehicles).set({ status: "aktivno" }).where(eq(vehicles.id, current.vehicleId));
    } else if (current && body.status === "u_toku") {
      await db.update(vehicles).set({ status: "servis" }).where(eq(vehicles.id, current.vehicleId));
    }
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Service PATCH error:", error);
    return NextResponse.json({ error: "Greška pri ažuriranju" }, { status: 500 });
  }
}

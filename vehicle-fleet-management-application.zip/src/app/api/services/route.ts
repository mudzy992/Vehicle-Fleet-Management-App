import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { services, vehicles } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get("status") ?? "";
    const rows = await db
      .select({
        id: services.id,
        vehicleId: services.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        tip: services.tip,
        naziv: services.naziv,
        opis: services.opis,
        serviser: services.serviser,
        datum: services.datum,
        kilometraza: services.kilometraza,
        iznos: services.iznos,
        status: services.status,
        sledeciServisKm: services.sledeciServisKm,
        sledeciServisDatum: services.sledeciServisDatum,
      })
      .from(services)
      .innerJoin(vehicles, eq(services.vehicleId, vehicles.id))
      .where(status ? eq(services.status, status as never) : undefined)
      .orderBy(desc(services.datum));
    return NextResponse.json(rows);
  } catch (error) {
    console.error("Services GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju servisa" }, { status: 500 });
  }
}

const serviceSchema = z.object({
  vehicleId: z.coerce.number().int(),
  tip: z.enum(["mali_servis", "veliki_servis", "popravka", "gume", "registracija_radovi", "ostalo"]).default("mali_servis"),
  naziv: z.string().min(2),
  opis: z.string().optional(),
  serviser: z.string().optional(),
  datum: z.string(),
  kilometraza: z.coerce.number().int().optional(),
  iznos: z.coerce.number().default(0),
  status: z.enum(["zakazan", "u_toku", "zavrsen"]).default("zakazan"),
  sledeciServisKm: z.coerce.number().int().optional(),
  sledeciServisDatum: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = serviceSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Neispravni podaci" }, { status: 400 });
    }
    const d = parsed.data;
    const [created] = await db
      .insert(services)
      .values({
        vehicleId: d.vehicleId,
        tip: d.tip,
        naziv: d.naziv,
        opis: d.opis || null,
        serviser: d.serviser || null,
        datum: d.datum,
        kilometraza: d.kilometraza ?? null,
        iznos: String(d.iznos),
        status: d.status,
        sledeciServisKm: d.sledeciServisKm ?? null,
        sledeciServisDatum: d.sledeciServisDatum || null,
      })
      .returning();

    if (d.status === "u_toku") {
      await db.update(vehicles).set({ status: "servis" }).where(eq(vehicles.id, d.vehicleId));
    }
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Services POST error:", error);
    return NextResponse.json({ error: "Greška pri dodavanju servisa" }, { status: 500 });
  }
}

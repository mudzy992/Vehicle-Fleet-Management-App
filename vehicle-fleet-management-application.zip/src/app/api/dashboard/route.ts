import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  vehicles,
  drivers,
  registrations,
  services,
  maintenancePlans,
  trips,
  fuelLogs,
  locations,
} from "@/db/schema";
import { desc, eq, sql, and, gte, lte } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const now = new Date();
    const in30 = new Date(Date.now() + 30 * 86400000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const [fleet] = await db
      .select({
        ukupno: sql<number>`count(*)::int`,
        aktivna: sql<number>`count(*) filter (where ${vehicles.status} = 'aktivno')::int`,
        servis: sql<number>`count(*) filter (where ${vehicles.status} = 'servis')::int`,
        ukupnoKm: sql<number>`coalesce(sum(${vehicles.kilometraza}),0)::int`,
      })
      .from(vehicles);

    const [driverStats] = await db
      .select({
        ukupno: sql<number>`count(*)::int`,
        aktivni: sql<number>`count(*) filter (where ${drivers.status} = 'aktivan')::int`,
      })
      .from(drivers);

    const [tripStats] = await db
      .select({
        uToku: sql<number>`count(*) filter (where ${trips.status} = 'u_toku')::int`,
        planirana: sql<number>`count(*) filter (where ${trips.status} = 'planiran')::int`,
        kmMjesec: sql<number>`coalesce(sum(${trips.predjenoKm}) filter (where ${trips.status}='zavrsen' and ${trips.datumPolaska} >= ${monthStart.toISOString()}::timestamptz),0)::int`,
      })
      .from(trips);

    const [fuelMonth] = await db
      .select({
        iznos: sql<number>`coalesce(sum(${fuelLogs.ukupanIznos}::numeric),0)::numeric`,
        litara: sql<number>`coalesce(sum(${fuelLogs.litara}::numeric),0)::numeric`,
      })
      .from(fuelLogs)
      .where(gte(fuelLogs.datum, monthStart.toISOString().slice(0, 10)));

    const [serviceMonth] = await db
      .select({
        iznos: sql<number>`coalesce(sum(${services.iznos}::numeric),0)::numeric`,
        aktivnih: sql<number>`count(*) filter (where ${services.status} in ('zakazan','u_toku'))::int`,
      })
      .from(services)
      .where(gte(services.datum, monthStart.toISOString().slice(0, 10)));

    // --- Troškovi po mjesecu (zadnjih 6) ---
    const fuelTrend = await db
      .select({
        mjesec: sql<string>`to_char(date_trunc('month', ${fuelLogs.datum}::date), 'Mon')`,
        sortKey: sql<string>`date_trunc('month', ${fuelLogs.datum}::date)::text`,
        gorivo: sql<number>`coalesce(sum(${fuelLogs.ukupanIznos}::numeric),0)::float`,
      })
      .from(fuelLogs)
      .groupBy(sql`1, 2`)
      .orderBy(sql`2`)
      .limit(6);

    const serviceTrend = await db
      .select({
        sortKey: sql<string>`date_trunc('month', ${services.datum}::date)::text`,
        servisi: sql<number>`coalesce(sum(${services.iznos}::numeric),0)::float`,
      })
      .from(services)
      .groupBy(sql`1`)
      .orderBy(sql`1`)
      .limit(6);

    const trendMap = new Map<string, { mjesec: string; gorivo: number; servisi: number }>();
    for (const f of fuelTrend) {
      trendMap.set(f.sortKey, { mjesec: f.mjesec, gorivo: f.gorivo, servisi: 0 });
    }
    for (const s of serviceTrend) {
      const existing = trendMap.get(s.sortKey);
      if (existing) existing.servisi = s.servisi;
      else trendMap.set(s.sortKey, { mjesec: s.sortKey.slice(5, 7), gorivo: 0, servisi: s.servisi });
    }
    const troskoviTrend = [...trendMap.values()].slice(-6);

    // --- Troškovi po vozilu ---
    const troskoviPoVozilu = await db
      .select({
        naziv: vehicles.naziv,
        gorivo: sql<number>`coalesce((select sum(${fuelLogs.ukupanIznos}::numeric) from ${fuelLogs} where ${fuelLogs.vehicleId} = ${vehicles.id}),0)::float`,
        servisi: sql<number>`coalesce((select sum(${services.iznos}::numeric) from ${services} where ${services.vehicleId} = ${vehicles.id}),0)::float`,
      })
      .from(vehicles)
      .orderBy(vehicles.id);

    // --- Alerti ---
    const istekleRegistracije = await db
      .select({
        id: registrations.id,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        vaziDo: registrations.vaziDo,
      })
      .from(registrations)
      .innerJoin(vehicles, eq(registrations.vehicleId, vehicles.id))
      .where(lte(registrations.vaziDo, in30.toISOString().slice(0, 10)));

    const isticeVozacka = await db
      .select({
        id: drivers.id,
        ime: drivers.ime,
        prezime: drivers.prezime,
        vaziDo: drivers.vozackaVaziDo,
      })
      .from(drivers)
      .where(lte(drivers.vozackaVaziDo, in30.toISOString().slice(0, 10)));

    const odrzavanje = await db
      .select({
        id: maintenancePlans.id,
        vozilo: vehicles.naziv,
        naslov: maintenancePlans.naslov,
        status: maintenancePlans.status,
      })
      .from(maintenancePlans)
      .innerJoin(vehicles, eq(maintenancePlans.vehicleId, vehicles.id))
      .where(sql`${maintenancePlans.status} in ('isteklo','predstoji')`);

    const zakazaniServisi = await db
      .select({
        id: services.id,
        vozilo: vehicles.naziv,
        naziv: services.naziv,
        datum: services.datum,
        status: services.status,
      })
      .from(services)
      .innerJoin(vehicles, eq(services.vehicleId, vehicles.id))
      .where(lte(services.datum, in30.toISOString().slice(0, 10)))
      .orderBy(services.datum)
      .limit(6);

    // --- Nedavni putni nalozi ---
    const nedavniNalozi = await db
      .select({
        id: trips.id,
        brojNaloga: trips.brojNaloga,
        polaziste: trips.polaziste,
        odrediste: trips.odrediste,
        status: trips.status,
        datumPolaska: trips.datumPolaska,
        predjenoKm: trips.predjenoKm,
        vozilo: vehicles.naziv,
        vozacIme: drivers.ime,
        vozacPrezime: drivers.prezime,
      })
      .from(trips)
      .innerJoin(vehicles, eq(trips.vehicleId, vehicles.id))
      .innerJoin(drivers, eq(trips.driverId, drivers.id))
      .orderBy(desc(trips.datumPolaska))
      .limit(6);

    // --- Lokacije (zadnje poznate po vozilu) ---
    const zadnjeLokacije = await db
      .selectDistinctOn([locations.vehicleId], {
        vehicleId: locations.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        lat: locations.lat,
        lng: locations.lng,
        adresa: locations.adresa,
        brzina: locations.brzina,
        vrijeme: locations.zapisaоAt,
        status: vehicles.status,
      })
      .from(locations)
      .innerJoin(vehicles, eq(locations.vehicleId, vehicles.id))
      .orderBy(locations.vehicleId, desc(locations.zapisaоAt));

    const alertCount =
      istekleRegistracije.length + isticeVozacka.length + odrzavanje.length;

    return NextResponse.json({
      kpi: {
        vozilaUkupno: fleet.ukupno,
        vozilaAktivna: fleet.aktivna,
        vozilaServis: fleet.servis,
        ukupnoKm: fleet.ukupnoKm,
        vozaciAktivni: driverStats.aktivni,
        vozaciUkupno: driverStats.ukupno,
        naloziUToku: tripStats.uToku,
        naloziPlanirani: tripStats.planirana,
        kmOvajMjesec: tripStats.kmMjesec,
        gorivoMjesec: Number(fuelMonth.iznos),
        litaraMjesec: Number(fuelMonth.litara),
        servisiMjesec: Number(serviceMonth.iznos),
        aktivnihServisa: serviceMonth.aktivnih,
        alerta: alertCount,
      },
      troskoviTrend,
      troskoviPoVozilu,
      alerti: {
        registracije: istekleRegistracije,
        vozacke: isticeVozacka,
        odrzavanje,
        servisi: zakazaniServisi,
      },
      nedavniNalozi,
      zadnjeLokacije,
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju nadzorne ploče" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { drivers } from "@/db/schema";
import { eq } from "drizzle-orm";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const allowed = ["ime", "prezime", "email", "telefon", "status", "kategorije", "vozackaVaziDo"] as const;
    const updates: Record<string, unknown> = {};
    for (const key of allowed) if (body[key] !== undefined) updates[key] = body[key];
    const [updated] = await db.update(drivers).set(updates).where(eq(drivers.id, Number(id))).returning();
    if (!updated) return NextResponse.json({ error: "Vozač nije pronađen" }, { status: 404 });
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Driver PATCH error:", error);
    return NextResponse.json({ error: "Greška pri ažuriranju" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    await db.delete(drivers).where(eq(drivers.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Vozač ima povezane naloge" }, { status: 409 });
  }
}

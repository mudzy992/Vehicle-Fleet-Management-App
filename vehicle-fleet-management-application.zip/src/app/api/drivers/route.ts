import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { drivers, trips } from "@/db/schema";
import { asc, sql } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: drivers.id,
        ime: drivers.ime,
        prezime: drivers.prezime,
        email: drivers.email,
        telefon: drivers.telefon,
        brojVozacke: drivers.brojVozacke,
        kategorije: drivers.kategorije,
        vozackaVaziDo: drivers.vozackaVaziDo,
        status: drivers.status,
        datumZaposlenja: drivers.datumZaposlenja,
        brojNaloga: sql<number>`(select count(*) from ${trips} where ${trips.driverId} = ${drivers.id})::int`,
        predjenoKm: sql<number>`coalesce((select sum(${trips.predjenoKm}) from ${trips} where ${trips.driverId} = ${drivers.id}),0)::int`,
      })
      .from(drivers)
      .orderBy(asc(drivers.prezime));
    return NextResponse.json(rows);
  } catch (error) {
    console.error("Drivers GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju vozača" }, { status: 500 });
  }
}

const driverSchema = z.object({
  ime: z.string().min(2),
  prezime: z.string().min(2),
  email: z.string().email(),
  telefon: z.string().min(6),
  brojVozacke: z.string().min(4),
  kategorije: z.string().default("B"),
  vozackaVaziDo: z.string(),
  datumZaposlenja: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = driverSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Neispravni podaci" }, { status: 400 });
    }
    const d = parsed.data;
    const [created] = await db
      .insert(drivers)
      .values({
        ime: d.ime,
        prezime: d.prezime,
        email: d.email,
        telefon: d.telefon,
        brojVozacke: d.brojVozacke.toUpperCase(),
        kategorije: d.kategorije,
        vozackaVaziDo: d.vozackaVaziDo,
        datumZaposlenja: d.datumZaposlenja || null,
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "";
    if (msg.includes("unique")) {
      return NextResponse.json({ error: "Email ili broj vozačke već postoji" }, { status: 409 });
    }
    console.error("Drivers POST error:", error);
    return NextResponse.json({ error: "Greška pri dodavanju vozača" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { fuelLogs, vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: fuelLogs.id,
        vehicleId: fuelLogs.vehicleId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        datum: fuelLogs.datum,
        litara: fuelLogs.litara,
        cijenaPoLitri: fuelLogs.cijenaPoLitri,
        ukupanIznos: fuelLogs.ukupanIznos,
        kilometraza: fuelLogs.kilometraza,
        pumpa: fuelLogs.pumpa,
      })
      .from(fuelLogs)
      .innerJoin(vehicles, eq(fuelLogs.vehicleId, vehicles.id))
      .orderBy(desc(fuelLogs.datum))
      .limit(60);
    return NextResponse.json(rows);
  } catch (error) {
    console.error("FuelLogs GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju goriva" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trips, vehicles } from "@/db/schema";
import { eq } from "drizzle-orm";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const [current] = await db.select().from(trips).where(eq(trips.id, Number(id)));
    if (!current) return NextResponse.json({ error: "Nalog nije pronađen" }, { status: 404 });

    const updates: Record<string, unknown> = {};
    if (body.status) updates.status = body.status;
    if (body.napomena !== undefined) updates.napomena = body.napomena;
    if (body.predjenoKm !== undefined) updates.predjenoKm = Number(body.predjenoKm);

    if (body.status === "u_toku") {
      updates.pocetnaKilometraza = current.pocetnaKilometraza ?? null;
    }
    if (body.status === "zavrsen") {
      updates.datumDolaska = new Date().toISOString();
      const km = Number(body.predjenoKm ?? current.predjenoKm ?? 0);
      updates.predjenoKm = km;
      const [v] = await db.select().from(vehicles).where(eq(vehicles.id, current.vehicleId));
      if (v) {
        const novaKm = (v.kilometraza ?? 0) + km;
        updates.zavrsnaKilometraza = novaKm;
        updates.pocetnaKilometraza = v.kilometraza;
        await db.update(vehicles).set({ kilometraza: novaKm }).where(eq(vehicles.id, v.id));
      }
    }

    const [updated] = await db.update(trips).set(updates).where(eq(trips.id, Number(id))).returning();
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Trip PATCH error:", error);
    return NextResponse.json({ error: "Greška pri ažuriranju naloga" }, { status: 500 });
  }
}

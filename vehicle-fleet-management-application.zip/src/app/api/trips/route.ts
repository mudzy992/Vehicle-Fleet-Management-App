import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trips, vehicles, drivers } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { z } from "zod";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get("status") ?? "";
    const rows = await db
      .select({
        id: trips.id,
        brojNaloga: trips.brojNaloga,
        vehicleId: trips.vehicleId,
        driverId: trips.driverId,
        vozilo: vehicles.naziv,
        oznaka: vehicles.registracionaOznaka,
        vozacIme: drivers.ime,
        vozacPrezime: drivers.prezime,
        polaziste: trips.polaziste,
        odrediste: trips.odrediste,
        svrha: trips.svrha,
        datumPolaska: trips.datumPolaska,
        datumDolaska: trips.datumDolaska,
        status: trips.status,
        predjenoKm: trips.predjenoKm,
        troskovi: trips.troskovi,
        napomena: trips.napomena,
      })
      .from(trips)
      .innerJoin(vehicles, eq(trips.vehicleId, vehicles.id))
      .innerJoin(drivers, eq(trips.driverId, drivers.id))
      .where(status ? eq(trips.status, status as never) : undefined)
      .orderBy(desc(trips.datumPolaska));
    return NextResponse.json(rows);
  } catch (error) {
    console.error("Trips GET error:", error);
    return NextResponse.json({ error: "Greška pri učitavanju naloga" }, { status: 500 });
  }
}

const tripSchema = z.object({
  vehicleId: z.coerce.number().int(),
  driverId: z.coerce.number().int(),
  polaziste: z.string().min(2),
  odrediste: z.string().min(2),
  svrha: z.string().optional(),
  datumPolaska: z.string(),
  datumDolaska: z.string().optional(),
  troskovi: z.coerce.number().default(0),
  napomena: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = tripSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Neispravni podaci" }, { status: 400 });
    }
    const d = parsed.data;

    const [seq] = await db.select({ n: sql<number>`count(*)::int` }).from(trips);
    const brojNaloga = `PN-${new Date().getFullYear()}-${String(seq.n + 153).padStart(4, "0")}`;

    const [created] = await db
      .insert(trips)
      .values({
        brojNaloga,
        vehicleId: d.vehicleId,
        driverId: d.driverId,
        polaziste: d.polaziste,
        odrediste: d.odrediste,
        svrha: d.svrha || null,
        datumPolaska: new Date(d.datumPolaska),
        datumDolaska: d.datumDolaska ? new Date(d.datumDolaska) : null,
        troskovi: String(d.troskovi),
        napomena: d.napomena || null,
        status: "planiran",
      })
      .returning();
    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Trips POST error:", error);
    return NextResponse.json({ error: "Greška pri kreiranju naloga" }, { status: 500 });
  }
}

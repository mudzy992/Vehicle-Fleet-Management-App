"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  ArrowRight,
  Car,
  FileCheck2,
  Fuel,
  Gauge,
  MapPin,
  Route,
  Smartphone,
  Users,
  Wrench,
  CheckCircle2,
  Terminal,
  Satellite,
  Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { CountUp } from "@/components/shared/count-up";
import { LiveMap, type MapVehicle, type MapTrail } from "@/components/shared/live-map";
import { useApi } from "@/components/shared/use-api";

type DashData = {
  kpi: {
    vozilaUkupno: number;
    vozilaAktivna: number;
    ukupnoKm: number;
    vozaciAktivni: number;
    kmOvajMjesec: number;
    alerta: number;
    naloziUToku: number;
  };
};

type LocData = { latest: MapVehicle[]; trails: MapTrail[] };

const FEATURES = [
  { icon: Car, num: "01", title: "Kompletan vozni park", desc: "Svako vozilo sa kilometražom, gorivom, dokumentacijom i troškovima — na jednom mjestu, u realnom vremenu." },
  { icon: FileCheck2, num: "02", title: "Registracije bez kašnjenja", desc: "Automatsko praćenje isteka registracija i polisa osiguranja sa odbrojavanjem dana i proaktivnim upozorenjima." },
  { icon: Wrench, num: "03", title: "Servisi i održavanje", desc: "Plan preventivnog održavanja po kilometraži i vremenu. Servisna istorija svakog vozila zauvijek sačuvana." },
  { icon: Route, num: "04", title: "Putni nalozi", desc: "Digitalni nalozi sa brojevima, vozačima, trasama i troškovima. Od planiranog do završenog — kompletan trag." },
  { icon: MapPin, num: "05", title: "Lokacije uživo", desc: "GPS telemetrija cijele flote na jednoj mapi. Brzina, adresa i trag kretanja svakog vozila." },
  { icon: Users, num: "06", title: "Upravljanje vozačima", desc: "Karton svakog vozača: kategorije dozvola, istek vozačke, pređeni kilometri i istorija naloga." },
];

const EASE = [0.22, 1, 0.36, 1] as const;

function Reveal({ children, delay = 0, className }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.9, delay, ease: EASE }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function LandingPage() {
  const { data: dash } = useApi<DashData>("/api/dashboard");
  const { data: loc } = useApi<LocData>("/api/locations");
  const [mouse, setMouse] = useState({ x: 0.5, y: 0.5 });
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 600], [0, 140]);
  const heroOpacity = useTransform(scrollY, [0, 500], [1, 0.1]);

  useEffect(() => {
    const fn = (e: MouseEvent) =>
      setMouse({ x: e.clientX / window.innerWidth, y: e.clientY / window.innerHeight });
    window.addEventListener("mousemove", fn);
    return () => window.removeEventListener("mousemove", fn);
  }, []);

  const kpi = dash?.kpi;

  return (
    <div className="min-h-screen overflow-x-clip bg-[#07080b] text-zinc-200 selection:bg-lime-400">
      {/* ---- NAV ---- */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/[0.06] bg-[#07080b]/70 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-lime-400 text-zinc-950 shadow-[0_0_26px_-6px_rgba(163,230,53,0.85)]">
              <Gauge className="h-5 w-5" strokeWidth={2.4} />
            </div>
            <span className="text-lg font-bold tracking-tight text-white">FLOTA</span>
            <span className="hidden font-mono text-[10px] uppercase tracking-[0.3em] text-zinc-500 sm:block">
              Fleet OS
            </span>
          </Link>
          <nav className="hidden items-center gap-7 text-sm text-zinc-400 md:flex">
            <a href="#funkcije" className="hover:text-lime-300 transition-colors">Funkcije</a>
            <a href="#mapa" className="hover:text-lime-300 transition-colors">Mapa uživo</a>
            <a href="#mobilna" className="hover:text-lime-300 transition-colors">Mobilna app</a>
          </nav>
          <Button asChild size="sm">
            <Link href="/dashboard">
              Kontrolni centar
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </header>

      {/* ---- HERO ---- */}
      <section className="relative flex min-h-[100svh] flex-col justify-end overflow-hidden pb-10 pt-28">
        <motion.div style={{ y: heroY, opacity: heroOpacity }} className="absolute inset-0">
          <Image
            src="/images/hero-roads.jpg"
            alt="Auto-putevi noću"
            fill
            priority
            className="object-cover scale-105"
            style={{
              transform: `translate(${(mouse.x - 0.5) * -18}px, ${(mouse.y - 0.5) * -12}px) scale(1.08)`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#07080b] via-[#07080b]/55 to-[#07080b]/30" />
          <div className="absolute inset-0 bg-blueprint opacity-60" />
        </motion.div>

        <div className="relative z-10 mx-auto w-full max-w-7xl px-5">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-lime-400/30 bg-lime-400/[0.08] px-4 py-1.5 backdrop-blur-sm"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute h-full w-full rounded-full bg-lime-400 animate-ping-dot" />
              <span className="relative h-2 w-2 rounded-full bg-lime-400" />
            </span>
            <span className="text-xs font-medium tracking-wide text-lime-200">
              Sistem aktivan — {kpi ? `${kpi.vozilaUkupno} vozila pod nadzorom` : "učitavanje telemetrije…"}
            </span>
          </motion.div>

          <h1 className="max-w-5xl text-[clamp(2.6rem,8.5vw,6.5rem)] font-bold leading-[0.95] tracking-[-0.03em] text-white">
            {["KOMPLETNA", "KONTROLA"].map((word, i) => (
              <span key={word} className="block overflow-hidden">
                <motion.span
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 1, delay: 0.15 + i * 0.12, ease: EASE }}
                  className="block"
                >
                  {word}
                </motion.span>
              </span>
            ))}
            <span className="block overflow-hidden">
              <motion.span
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 1, delay: 0.39, ease: EASE }}
                className="block text-lime-300"
              >
                VOZNOG PARKA.
              </motion.span>
            </span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.55, ease: EASE }}
            className="mt-6 max-w-xl text-base leading-relaxed text-zinc-400 sm:text-lg"
          >
            Vozila, vozači, registracije, servisi, putni nalozi i lokacije — objedinjeni u
            jednu platformu sa moćnim REST API-jem i mobilnom aplikacijom spremnom za teren.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.68, ease: EASE }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <Button asChild size="lg">
              <Link href="/dashboard">
                Pokreni kontrolni centar
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="#mobilna">
                <Smartphone className="h-5 w-5" />
                Expo mobilna app
              </a>
            </Button>
          </motion.div>

          {/* KPI traka */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.85, ease: EASE }}
            className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.06] backdrop-blur-md sm:grid-cols-4"
          >
            {[
              { label: "Vozila u floti", value: kpi?.vozilaUkupno ?? 0, suffix: "" },
              { label: "Km ove sedmice+", value: kpi?.kmOvajMjesec ?? 0, suffix: "" },
              { label: "Aktivnih vozača", value: kpi?.vozaciAktivni ?? 0, suffix: "" },
              { label: "Nalozi u toku", value: kpi?.naloziUToku ?? 0, suffix: "" },
            ].map((s) => (
              <div key={s.label} className="bg-[#0a0c10]/90 p-5">
                <div className="text-3xl font-bold text-white sm:text-4xl">
                  <CountUp value={s.value} />
                </div>
                <div className="mt-1 text-[11px] font-mono uppercase tracking-[0.2em] text-zinc-500">
                  {s.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ---- MARQUEE ---- */}
      <div className="relative border-y border-white/[0.07] bg-zinc-950/60 py-4 overflow-hidden">
        <div className="animate-marquee flex w-max gap-10 whitespace-nowrap">
          {Array.from({ length: 2 }).map((_, dup) => (
            <div key={dup} className="flex gap-10">
              {[
                "VOZILA", "VOZAČI", "REGISTRACIJE", "SERVISI", "ODRŽAVANJE",
                "PUTNI NALOZI", "GPS LOKACIJE", "GORIVO", "REST API", "EXPO APP",
              ].map((t) => (
                <span key={t} className="flex items-center gap-10 text-sm font-mono uppercase tracking-[0.3em] text-zinc-500">
                  {t}
                  <span className="h-1.5 w-1.5 rounded-full bg-lime-400/70" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ---- FEATURES BENTO ---- */}
      <section id="funkcije" className="relative mx-auto max-w-7xl px-5 py-28">
        <Reveal>
          <div className="mb-14 flex items-end justify-between">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <span className="h-px w-8 bg-lime-400/70" />
                <span className="font-mono text-[11px] uppercase tracking-[0.28em] text-lime-300/90">
                  Moduli sistema
                </span>
              </div>
              <h2 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
                Sve što flota traži.<br />
                <span className="text-stroke">Ništa što ne treba.</span>
              </h2>
            </div>
            <div className="hidden text-right font-mono text-xs text-zinc-600 sm:block">
              [ 06 KLIJUČNIH MODULA ]
            </div>
          </div>
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <Reveal key={f.num} delay={i * 0.07}>
              <div className="group relative h-full overflow-hidden rounded-2xl border border-white/[0.07] bg-zinc-900/50 p-6 transition-all duration-500 hover:border-lime-400/40 hover:bg-zinc-900/80 hover:shadow-[0_0_50px_-18px_rgba(163,230,53,0.4)]">
                <div className="absolute -right-6 -top-8 font-mono text-8xl font-bold text-white/[0.04] transition-colors duration-500 group-hover:text-lime-400/[0.08]">
                  {f.num}
                </div>
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl border border-lime-400/25 bg-lime-400/10 text-lime-300 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-white">{f.title}</h3>
                <p className="text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---- LIVE MAP PREVIEW ---- */}
      <section id="mapa" className="relative mx-auto max-w-7xl px-5 pb-28">
        <Reveal>
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <span className="h-px w-8 bg-lime-400/70" />
                <span className="font-mono text-[11px] uppercase tracking-[0.28em] text-lime-300/90">
                  Telemetrija uživo
                </span>
              </div>
              <h2 className="flex items-center gap-4 text-4xl font-bold tracking-tight text-white sm:text-5xl">
                <Satellite className="h-9 w-9 text-lime-300" />
                Cijela flota na jednoj mapi.
              </h2>
            </div>
            <Button asChild variant="outline">
              <Link href="/lokacije">
                Otvori puni prikaz
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="relative rounded-3xl border border-white/[0.08] bg-zinc-900/40 p-2 shadow-[0_40px_120px_-40px_rgba(163,230,53,0.25)]">
            {loc ? (
              <LiveMap latest={loc.latest} trails={loc.trails} className="h-[520px]" />
            ) : (
              <div className="flex h-[520px] items-center justify-center rounded-2xl bg-zinc-900/60">
                <div className="flex items-center gap-3 text-zinc-500">
                  <Activity className="h-5 w-5 animate-pulse" />
                  Uspostavljanje GPS veze…
                </div>
              </div>
            )}
          </div>
        </Reveal>
      </section>

      {/* ---- MOBILNA APP ---- */}
      <section id="mobilna" className="relative overflow-hidden border-t border-white/[0.06] bg-zinc-950/40 py-28">
        <div className="pointer-events-none absolute -left-40 top-1/3 h-[420px] w-[420px] rounded-full bg-lime-400/[0.07] blur-[120px]" />
        <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 lg:grid-cols-2">
          <Reveal>
            <div>
              <div className="mb-3 flex items-center gap-2">
                <span className="h-px w-8 bg-lime-400/70" />
                <span className="font-mono text-[11px] uppercase tracking-[0.28em] text-lime-300/90">
                  Expo ready
                </span>
              </div>
              <h2 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
                Ista moć.<br />U džepu svakog vozača.
              </h2>
              <p className="mt-5 max-w-md text-zinc-400 leading-relaxed">
                Mobilna aplikacija (React Native + Expo) komunicira sa istim REST API-jem koji
                vidiš u pregledaču. Prijava naloga, prijava kilometraže, sken dokumenata —
                sve sa terena, u realnom vremenu.
              </p>
              <ul className="mt-7 space-y-3">
                {[
                  "Dijeljeni REST API između web i mobilne app",
                  "Tipizirani Klijent — jedan izvor istine",
                  "Push notifikacije za istek registracija",
                  "Offline-first putni nalozi",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-3 text-sm text-zinc-300">
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-lime-300" />
                    {t}
                  </li>
                ))}
              </ul>
              <div className="mt-8 flex gap-3">
                <Button asChild>
                  <Link href="/mobilna-aplikacija">
                    Vodič za Expo setup
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.15} className="relative">
            <div className="mx-auto flex max-w-none flex-col items-center gap-8 sm:flex-row sm:justify-center">
              {/* Telefon mock */}
              <div className="animate-float-slow relative h-[560px] w-[270px] shrink-0 rounded-[44px] border border-white/15 bg-zinc-950 p-2.5 shadow-[0_50px_100px_-30px_rgba(163,230,53,0.3)]">
                <div className="noise relative h-full w-full overflow-hidden rounded-[36px] bg-[#0a0c10]">
                  <div className="absolute left-1/2 top-2.5 h-6 w-24 -translate-x-1/2 rounded-full bg-zinc-950 border border-white/[0.06]" />
                  <div className="px-4 pt-12">
                    <div className="mb-1 font-mono text-[9px] uppercase tracking-[0.25em] text-zinc-500">
                      FLOTA • Mobile
                    </div>
                    <div className="text-lg font-bold text-white">Zdravo, Marko</div>
                    <div className="mt-4 rounded-2xl border border-lime-400/30 bg-lime-400/[0.08] p-3.5">
                      <div className="font-mono text-[9px] uppercase tracking-widest text-lime-300">
                        Aktivni nalog
                      </div>
                      <div className="mt-1.5 text-sm font-semibold text-white">BG → Zagreb</div>
                      <div className="mt-1 text-[11px] text-zinc-400">PN-2025-0149 • Tiguan</div>
                      <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-white/10">
                        <div className="h-full w-2/3 rounded-full bg-lime-400" />
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2.5">
                      <div className="rounded-2xl border border-white/[0.07] bg-zinc-900/70 p-3">
                        <Fuel className="mb-2 h-4 w-4 text-lime-300" />
                        <div className="text-base font-bold text-white">6.8L</div>
                        <div className="text-[9px] text-zinc-500">prosjek /100km</div>
                      </div>
                      <div className="rounded-2xl border border-white/[0.07] bg-zinc-900/70 p-3">
                        <FileCheck2 className="mb-2 h-4 w-4 text-amber-300" />
                        <div className="text-base font-bold text-white">35d</div>
                        <div className="text-[9px] text-zinc-500">do registracije</div>
                      </div>
                    </div>
                    <div className="mt-3 rounded-2xl border border-white/[0.07] bg-zinc-900/70 p-3">
                      <div className="mb-2 text-[10px] font-mono uppercase tracking-widest text-zinc-500">
                        Brze akcije
                      </div>
                      {["Prijavi kilometražu", "Završi nalog", "Prijavi kvar"].map((b) => (
                        <div key={b} className="mt-1.5 rounded-xl bg-white/[0.05] px-3 py-2 text-[11px] font-medium text-zinc-300">
                          {b}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Terminal */}
              <div className="w-full max-w-sm overflow-hidden rounded-2xl border border-white/10 bg-zinc-950 shadow-2xl">
                <div className="flex items-center gap-2 border-b border-white/[0.07] px-4 py-2.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-lime-400/70" />
                  <span className="ml-2 font-mono text-[10px] text-zinc-500">terminal</span>
                </div>
                <div className="space-y-1.5 p-4 font-mono text-[11px] leading-relaxed">
                  <div className="text-zinc-500"><span className="text-lime-300">$</span> npx create-expo-app flota-mobile</div>
                  <div className="text-zinc-600">✔ Expo projekt kreiran</div>
                  <div className="text-zinc-500"><span className="text-lime-300">$</span> export API_URL=<span className="text-sky-300">/api</span></div>
                  <div className="text-zinc-500"><span className="text-lime-300">$</span> npx expo start</div>
                  <div className="flex items-center gap-2 text-zinc-400">
                    <Terminal className="h-3 w-3 text-lime-300" />
                    Spremno za teren — konektovano na FLOTA API
                  </div>
                  <div className="pt-1 text-lime-400/80">GET /api/vehicles → 200 OK (14ms)</div>
                  <div className="text-lime-400/80">GET /api/locations → 200 OK (9ms)</div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---- CTA FOOTER ---- */}
      <footer className="relative overflow-hidden border-t border-white/[0.06]">
        <div className="bg-dots absolute inset-0" />
        <div className="relative mx-auto max-w-7xl px-5 py-24 text-center">
          <Reveal>
            <h2 className="mx-auto max-w-3xl text-4xl font-bold tracking-tight text-white sm:text-6xl">
              Flota pod punom kontrolom.
              <span className="text-lime-300"> Od danas.</span>
            </h2>
            <div className="mt-9 flex justify-center gap-3">
              <Button asChild size="lg">
                <Link href="/dashboard">
                  Uđi u kontrolni centar
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
            <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 text-xs text-zinc-600 sm:flex-row">
              <span>FLOTA Fleet OS — Upravljanje voznim parkom</span>
              <span className="font-mono tracking-widest">API v1 • PostgreSQL • Next.js • Expo</span>
            </div>
          </Reveal>
        </div>
      </footer>
    </div>
  );
}

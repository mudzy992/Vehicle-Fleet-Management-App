"use client";

import { motion } from "framer-motion";
import { Radio, Gauge, MapPin, CarFront } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { LiveMap, type MapVehicle, type MapTrail } from "@/components/shared/live-map";
import { useApi } from "@/components/shared/use-api";
import { Skeleton } from "@/components/ui/extras";
import { formatDateTime } from "@/lib/format";

type LocData = {
  latest: (MapVehicle & { vrijeme: string })[];
  trails: MapTrail[];
};

export default function LokacijePage() {
  const { data, loading } = useApi<LocData>("/api/locations", 15000);

  const uPokretu = data?.latest.filter((v) => v.brzina > 0).length ?? 0;
  const parkirano = data?.latest.filter((v) => v.brzina === 0).length ?? 0;
  const maxBrzina = Math.max(0, ...(data?.latest.map((v) => v.brzina) ?? [0]));

  return (
    <AppShell>
      <PageHeader
        eyebrow="Telemetrija"
        title="Lokacije uživo"
        description="GPS pozicija svakog vozila sa brzinom, adresom i tragom kretanja. Automatsko osvježavanje svakih 15 sekundi."
      />

      {/* Stat strip */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.05 }}
        className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4"
      >
        {[
          { icon: CarFront, label: "Vozila na mapi", value: data?.latest.length ?? "…" },
          { icon: Radio, label: "U pokretu", value: loading ? "…" : uPokretu },
          { icon: MapPin, label: "Parkirano", value: loading ? "…" : parkirano },
          { icon: Gauge, label: "Max brzina", value: loading ? "…" : `${maxBrzina} km/h` },
        ].map((s) => (
          <div key={s.label} className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-zinc-900/60 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-lime-400/25 bg-lime-400/10">
              <s.icon className="h-4.5 w-4.5 text-lime-300" />
            </div>
            <div>
              <div className="text-xl font-bold text-white">{s.value}</div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">{s.label}</div>
            </div>
          </div>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
      >
        {loading || !data ? (
          <Skeleton className="h-[620px]" />
        ) : (
          <>
            <LiveMap latest={data.latest} trails={data.trails} className="h-[620px] border border-white/[0.08]" />
            <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
              {data.latest.map((v) => (
                <div key={v.vehicleId} className="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-zinc-900/50 px-3.5 py-3">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{
                      backgroundColor: v.status === "servis" ? "#fbbf24" : v.brzina > 0 ? "#a3e635" : "#71717a",
                      boxShadow: v.brzina > 0 ? "0 0 12px currentColor" : undefined,
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-semibold text-zinc-200">{v.vozilo}</div>
                    <div className="truncate text-[11px] text-zinc-500">{v.adresa}</div>
                  </div>
                  <div className="font-mono text-[10px] text-zinc-500">
                    {v.brzina > 0 ? `${v.brzina} km/h` : "0 km/h"}
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-widest text-zinc-700">
              Zadnja sinhronizacija: {formatDateTime(data.latest[0]?.vrijeme)} • softverski GPS modul
            </p>
          </>
        )}
      </motion.div>
    </AppShell>
  );
}

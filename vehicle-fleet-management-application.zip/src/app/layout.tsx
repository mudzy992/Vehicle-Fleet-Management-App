import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Space_Grotesk, JetBrains_Mono } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

const grotesk = Space_Grotesk({
  subsets: ["latin", "latin-ext"],
  variable: "--font-grotesk",
  weight: ["400", "500", "600", "700"],
});

const mono = JetBrains_Mono({
  subsets: ["latin", "latin-ext"],
  variable: "--font-mono",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "FLOTA — Upravljanje voznim parkom",
  description:
    "Kompletna platforma za praćenje voznog parka: vozila, vozači, registracije, servisi, putni nalozi, lokacije i gorivo — uz spreman backend API i Expo mobilnu aplikaciju.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="sr" className="dark">
      <body className={`${grotesk.variable} ${mono.variable} font-sans antialiased`}>
        {children}
        <Toaster
          theme="dark"
          position="bottom-right"
          toastOptions={{
            style: {
              background: "#18181b",
              border: "1px solid rgba(163,230,53,0.25)",
              color: "#e4e4e7",
            },
          }}
        />
      </body>
    </html>
  );
}

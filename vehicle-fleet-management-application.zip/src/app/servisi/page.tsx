"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, Wrench, CalendarClock, CircleCheck, Play, Package } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { StatusPill } from "@/components/shared/status-pill";
import { useApi } from "@/components/shared/use-api";
import { apiSend } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton, Progress } from "@/components/ui/extras";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { formatRSD, formatKm, formatDate } from "@/lib/format";
import { serviceTypeLabel } from "@/lib/labels";

type ServiceRow = {
  id: number; vehicleId: number; vozilo: string; oznaka: string; tip: string;
  naziv: string; serviser: string | null; datum: string; kilometraza: number | null;
  iznos: string; status: string;
};

type PlanRow = {
  id: number; vehicleId: number; vozilo: string; oznaka: string; trenutnaKm: number;
  naslov: string; intervalKm: number | null; intervalDana: number | null;
  zadnjeIzvrseno: string | null; zadnjeIzvrsenoKm: number | null; status: string;
};

type VehicleOption = { id: number; naziv: string; registracionaOznaka: string; kilometraza: number };

function AddServiceDialog({ vehicles, onDone }: { vehicles: VehicleOption[]; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    vehicleId: "", tip: "mali_servis", naziv: "", serviser: "", datum: "",
    kilometraza: "", iznos: "", status: "zakazan", opis: "",
  });

  const submit = async () => {
    if (!form.vehicleId || !form.naziv || !form.datum) {
      toast.error("Vozilo, naziv i datum su obavezni");
      return;
    }
    setSaving(true);
    try {
      await apiSend("/api/services", "POST", {
        vehicleId: Number(form.vehicleId),
        tip: form.tip,
        naziv: form.naziv,
        serviser: form.serviser || undefined,
        datum: form.datum,
        kilometraza: form.kilometraza ? Number(form.kilometraza) : undefined,
        iznos: form.iznos ? Number(form.iznos) : 0,
        status: form.status,
        opis: form.opis || undefined,
      });
      toast.success("Servis evidentiran");
      setOpen(false);
      setForm({ vehicleId: "", tip: "mali_servis", naziv: "", serviser: "", datum: "", kilometraza: "", iznos: "", status: "zakazan", opis: "" });
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4" /> Novi servis</Button>
      </DialogTrigger>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Evidentiraj servis</DialogTitle>
          <DialogDescription>Zakazani, servisi u toku ili već završeni radovi.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Vozilo *</Label>
            <Select value={form.vehicleId} onValueChange={(v) => setForm((f) => ({ ...f, vehicleId: v }))}>
              <SelectTrigger><SelectValue placeholder="Izaberi vozilo…" /></SelectTrigger>
              <SelectContent>
                {vehicles.map((v) => (
                  <SelectItem key={v.id} value={String(v.id)}>
                    {v.naziv} ({v.registracionaOznaka})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Naziv usluge *</Label>
            <Input placeholder="npr. Mali servis — ulje i filteri" value={form.naziv} onChange={(e) => setForm((f) => ({ ...f, naziv: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Tip</Label>
            <Select value={form.tip} onValueChange={(v) => setForm((f) => ({ ...f, tip: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(serviceTypeLabel).map(([val, lab]) => (
                  <SelectItem key={val} value={val}>{lab}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="zakazan">Zakazan</SelectItem>
                <SelectItem value="u_toku">U toku</SelectItem>
                <SelectItem value="zavrsen">Završen</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Datum *</Label>
            <Input type="date" value={form.datum} onChange={(e) => setForm((f) => ({ ...f, datum: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Serviser</Label>
            <Input placeholder="AutoCentar…" value={form.serviser} onChange={(e) => setForm((f) => ({ ...f, serviser: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Kilometraža</Label>
            <Input type="number" placeholder="86500" value={form.kilometraza} onChange={(e) => setForm((f) => ({ ...f, kilometraza: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Iznos (RSD)</Label>
            <Input type="number" placeholder="32000" value={form.iznos} onChange={(e) => setForm((f) => ({ ...f, iznos: e.target.value }))} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Opis radova</Label>
            <Textarea placeholder="Zamijenjeno: ulje, filteri…" value={form.opis} onChange={(e) => setForm((f) => ({ ...f, opis: e.target.value }))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>Otkaži</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Čuvanje…" : "Sačuvaj servis"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ServisiPage() {
  const { data: servisi, loading, reload } = useApi<ServiceRow[]>("/api/services", 60000);
  const { data: plan, reload: reloadPlan } = useApi<PlanRow[]>("/api/maintenance");
  const { data: vozila } = useApi<VehicleOption[]>("/api/vehicles");

  const updateStatus = async (id: number, status: string) => {
    try {
      await apiSend(`/api/services/${id}`, "PATCH", { status });
      toast.success(status === "zavrsen" ? "Servis završen — vozilo vraćeno u flotu" : "Status ažuriran");
      reload(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    }
  };

  const completePlan = async (id: number) => {
    try {
      await apiSend("/api/maintenance", "PATCH", { id, status: "uradjeno" });
      toast.success("Stavka održavanja označena kao urađena");
      reloadPlan(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    }
  };

  const ukupanTrosak = servisi?.reduce((acc, s) => acc + Number(s.iznos), 0) ?? 0;

  return (
    <AppShell>
      <PageHeader
        eyebrow="Održavanje"
        title="Servisi i plan održavanja"
        description="Zakazani i završeni servisi, preventivne stavke po kilometraži i vremenu."
        actions={<AddServiceDialog vehicles={vozila ?? []} onDone={() => reload(true)} />}
      />

      <Tabs defaultValue="servisi">
        <TabsList>
          <TabsTrigger value="servisi">Servisna istorija ({servisi?.length ?? "…"})</TabsTrigger>
          <TabsTrigger value="plan">Plan održavanja ({plan?.length ?? "…"})</TabsTrigger>
        </TabsList>

        <TabsContent value="servisi">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Card className="mb-4">
              <CardContent className="flex flex-wrap items-center gap-x-10 gap-y-2 p-5">
                <div className="flex items-center gap-3">
                  <Package className="h-5 w-5 text-lime-300" />
                  <div>
                    <div className="text-2xl font-bold text-white">{formatRSD(ukupanTrosak)}</div>
                    <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">ukupno troškova servisa</div>
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">{servisi?.filter((s) => s.status !== "zavrsen").length ?? 0}</div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">aktivnih servisa</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              {loading ? (
                <div className="space-y-3 p-5">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Vozilo</TableHead><TableHead>Usluga</TableHead><TableHead>Tip</TableHead>
                      <TableHead>Datum</TableHead><TableHead>Iznos</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Akcija</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {servisi?.map((s) => (
                      <TableRow key={s.id}>
                        <TableCell>
                          <div className="font-medium text-zinc-100">{s.vozilo}</div>
                          <div className="font-mono text-[10px] text-zinc-600">{s.oznaka}</div>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-56">
                            <div className="truncate text-sm text-zinc-200">{s.naziv}</div>
                            <div className="truncate text-[11px] text-zinc-500">{s.serviser}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">{serviceTypeLabel[s.tip]}</TableCell>
                        <TableCell className="font-mono text-xs">{formatDate(s.datum)}</TableCell>
                        <TableCell className="font-mono text-xs text-lime-300">{formatRSD(s.iznos)}</TableCell>
                        <TableCell><StatusPill status={s.status} /></TableCell>
                        <TableCell className="text-right">
                          {s.status === "zakazan" && (
                            <Button size="sm" variant="secondary" onClick={() => updateStatus(s.id, "u_toku")}>
                              <Play className="h-3.5 w-3.5" /> Započni
                            </Button>
                          )}
                          {s.status === "u_toku" && (
                            <Button size="sm" onClick={() => updateStatus(s.id, "zavrsen")}>
                              <CircleCheck className="h-3.5 w-3.5" /> Završi
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </Card>
          </motion.div>
        </TabsContent>

        <TabsContent value="plan">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {plan?.map((p, i) => {
              const napredak =
                p.intervalKm && p.zadnjeIzvrsenoKm != null
                  ? Math.min(100, Math.max(0, ((p.trenutnaKm - p.zadnjeIzvrsenoKm) / p.intervalKm) * 100))
                  : null;
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.04 }}
                >
                  <Card className="h-full">
                    <CardHeader className="flex-row items-start justify-between space-y-0 p-5 pb-3">
                      <div>
                        <CardTitle className="flex items-center gap-2 text-base">
                          <Wrench className="h-4 w-4 text-lime-300" />
                          {p.naslov}
                        </CardTitle>
                        <div className="mt-1 text-xs text-zinc-500">{p.vozilo} • {p.oznaka}</div>
                      </div>
                      <StatusPill status={p.status} />
                    </CardHeader>
                    <CardContent className="space-y-3 p-5 pt-0">
                      <div className="flex flex-wrap gap-2 text-[11px] text-zinc-400">
                        {p.intervalKm && <span className="rounded-lg bg-white/[0.04] px-2.5 py-1 font-mono">svakih {formatKm(p.intervalKm)}</span>}
                        {p.intervalDana && <span className="rounded-lg bg-white/[0.04] px-2.5 py-1 font-mono">svakih {p.intervalDana}d</span>}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <CalendarClock className="h-3.5 w-3.5" />
                        Zadnje: {formatDate(p.zadnjeIzvrseno)} {p.zadnjeIzvrsenoKm != null ? `• ${formatKm(p.zadnjeIzvrsenoKm)}` : ""}
                      </div>
                      {napredak != null && (
                        <div>
                          <div className="mb-1.5 flex justify-between text-[10px] font-mono uppercase tracking-widest text-zinc-600">
                            <span>Iskorišteno intervala</span>
                            <span className={napredak > 90 ? "text-red-300" : napredak > 70 ? "text-amber-300" : ""}>
                              {Math.round(napredak)}%
                            </span>
                          </div>
                          <Progress
                            value={napredak}
                            indicatorClassName={napredak > 90 ? "bg-red-400" : napredak > 70 ? "bg-amber-400" : "bg-lime-400"}
                          />
                        </div>
                      )}
                      {p.status !== "uradjeno" && (
                        <Button size="sm" variant="outline" className="w-full" onClick={() => completePlan(p.id)}>
                          <CircleCheck className="h-3.5 w-3.5" /> Označi kao urađeno
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
          {plan && plan.length === 0 && (
            <p className="py-16 text-center text-sm text-zinc-500">Nema definisanog plana održavanja.</p>
          )}
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}

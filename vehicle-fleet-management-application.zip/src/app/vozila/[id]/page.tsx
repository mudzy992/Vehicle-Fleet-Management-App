"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import {
  ArrowLeft, Gauge, Calendar, Palette, Fuel, Hash, FileCheck2,
  Wrench, Route, Droplets, MapPin, TrendingUp,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { StatusPill } from "@/components/shared/status-pill";
import { VehicleVisual } from "@/components/shared/vehicle-visual";
import { useApi } from "@/components/shared/use-api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton, Separator, AvatarCircle } from "@/components/ui/extras";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { formatRSD, formatKm, formatDate, formatDateTime, daysUntil } from "@/lib/format";
import { serviceTypeLabel, fuelTypeLabel, maintenanceStatusLabel } from "@/lib/labels";

type Detail = {
  vehicle: {
    id: number; naziv: string; marka: string; model: string; tip: string;
    godiste: number; registracionaOznaka: string; brojSasije: string;
    gorivo: string; status: string; kilometraza: number; boja: string | null;
    datumNabavke: string | null;
  };
  servisi: {
    id: number; tip: string; naziv: string; serviser: string | null;
    datum: string; kilometraza: number | null; iznos: string; status: string;
  }[];
  registracije: {
    id: number; datumRegistracije: string; vaziDo: string;
    osiguravajucaKuca: string | null; brojPolice: string | null; iznos: string; placeno: boolean;
  }[];
  plan: {
    id: number; naslov: string; intervalKm: number | null; intervalDana: number | null;
    zadnjeIzvrseno: string | null; status: string;
  }[];
  nalozi: {
    id: number; brojNaloga: string; polaziste: string; odrediste: string;
    status: string; datumPolaska: string; predjenoKm: number;
    vozacIme: string; vozacPrezime: string;
  }[];
  gorivo: {
    id: number; datum: string; litara: string; cijenaPoLitri: string;
    ukupanIznos: string; kilometraza: number | null; pumpa: string | null;
  }[];
  lokacija: { adresa: string | null; brzina: number; zapisaоAt: string } | null;
  trosakServisi: number;
  trosakGorivo: number;
};

function StatBox({ icon: Icon, label, value, mono }: { icon: React.ElementType; label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-xl border border-white/[0.06] bg-white/[0.03] p-3.5">
      <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-zinc-500">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <div className={`mt-1.5 text-sm font-semibold text-zinc-100 ${mono ? "font-mono" : ""}`}>{value}</div>
    </div>
  );
}

export default function VoziloDetailPage() {
  const params = useParams();
  const id = params?.id as string;
  const { data, loading } = useApi<Detail>(`/api/vehicles/${id}`);

  if (loading) {
    return (
      <AppShell>
        <Skeleton className="h-72 w-full" />
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-48" /><Skeleton className="h-48" /><Skeleton className="h-48" />
        </div>
      </AppShell>
    );
  }

  if (!data) {
    return (
      <AppShell>
        <div className="py-24 text-center text-zinc-500">Vozilo nije pronađeno.</div>
      </AppShell>
    );
  }

  const { vehicle: v } = data;
  const aktivnaReg = data.registracije[0];
  const regDani = aktivnaReg ? daysUntil(aktivnaReg.vaziDo) : null;

  return (
    <AppShell>
      <Link href="/vozila" className="mb-5 inline-flex items-center gap-2 text-sm text-zinc-500 hover:text-lime-300 transition-colors">
        <ArrowLeft className="h-4 w-4" /> Nazad na vozila
      </Link>

      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="group relative overflow-hidden rounded-3xl border border-white/[0.07] bg-zinc-900/60"
      >
        <div className="grid lg:grid-cols-5">
          <VehicleVisual tip={v.tip} className="h-64 lg:h-full lg:col-span-2" />
          <div className="relative p-6 sm:p-8 lg:col-span-3">
            <div className="bg-blueprint pointer-events-none absolute inset-0 opacity-50" />
            <div className="relative">
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-lg border border-white/15 bg-zinc-950/80 px-3 py-1.5 font-mono text-sm font-bold tracking-widest text-white">
                  {v.registracionaOznaka}
                </span>
                <StatusPill status={v.status} />
              </div>
              <h1 className="mt-4 text-3xl font-bold tracking-tight text-white sm:text-4xl">{v.naziv}</h1>
              <p className="mt-1.5 text-zinc-400">
                {v.marka} {v.model} • {v.godiste}. godište • {fuelTypeLabel[v.gorivo]}
              </p>

              <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
                <StatBox icon={Gauge} label="Kilometraža" value={formatKm(v.kilometraza)} mono />
                <StatBox icon={Hash} label="VIN šasija" value={v.brojSasije.slice(-9)} mono />
                <StatBox icon={Palette} label="Boja" value={v.boja ?? "—"} />
                <StatBox icon={Calendar} label="Nabavljeno" value={formatDate(v.datumNabavke)} />
                <StatBox icon={Wrench} label="Troškovi servisa" value={formatRSD(data.trosakServisi)} mono />
                <StatBox icon={Droplets} label="Troškovi goriva" value={formatRSD(data.trosakGorivo)} mono />
              </div>

              {data.lokacija && (
                <div className="mt-5 flex items-center gap-2.5 rounded-xl border border-lime-400/20 bg-lime-400/[0.06] px-4 py-3 text-sm">
                  <MapPin className="h-4 w-4 shrink-0 text-lime-300" />
                  <span className="text-zinc-300">{data.lokacija.adresa}</span>
                  <span className="ml-auto font-mono text-[10px] uppercase tracking-widest text-zinc-500">
                    {data.lokacija.brzina > 0 ? `${data.lokacija.brzina} km/h` : "parkirano"} • {formatDateTime(data.lokacija.zapisaоAt)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Registracija status */}
      {aktivnaReg && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-4"
        >
          <Card>
            <CardContent className="flex flex-wrap items-center gap-x-8 gap-y-3 p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-lime-400/25 bg-lime-400/10">
                  <FileCheck2 className="h-5 w-5 text-lime-300" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">Aktuelna registracija</div>
                  <div className="text-xs text-zinc-500">{aktivnaReg.osiguravajucaKuca} • polisa {aktivnaReg.brojPolice}</div>
                </div>
              </div>
              <div className="font-mono text-sm text-zinc-300">
                {formatDate(aktivnaReg.datumRegistracije)} → <span className="text-white">{formatDate(aktivnaReg.vaziDo)}</span>
              </div>
              <div className="font-semibold text-white">{formatRSD(aktivnaReg.iznos)}</div>
              {regDani != null && (
                <div className={`ml-auto rounded-xl px-4 py-2 text-center ${regDani < 0 ? "bg-red-400/10 text-red-300" : regDani <= 30 ? "bg-amber-400/10 text-amber-300" : "bg-emerald-400/10 text-emerald-300"}`}>
                  <div className="text-xl font-bold leading-none">{regDani < 0 ? -regDani : regDani}</div>
                  <div className="text-[9px] font-mono uppercase tracking-widest">{regDani < 0 ? "dana prekoračeno" : "dana preostalo"}</div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Tabovi */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.22 }}
        className="mt-6"
      >
        <Tabs defaultValue="servisi">
          <TabsList className="flex-wrap">
            <TabsTrigger value="servisi">Servisi ({data.servisi.length})</TabsTrigger>
            <TabsTrigger value="odrzavanje">Plan održavanja</TabsTrigger>
            <TabsTrigger value="nalozi">Nalozi ({data.nalozi.length})</TabsTrigger>
            <TabsTrigger value="gorivo">Gorivo</TabsTrigger>
          </TabsList>

          <TabsContent value="servisi">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Usluga</TableHead><TableHead>Tip</TableHead><TableHead>Serviser</TableHead>
                    <TableHead>Datum</TableHead><TableHead>Km</TableHead><TableHead>Iznos</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.servisi.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium text-zinc-100">{s.naziv}</TableCell>
                      <TableCell className="text-xs">{serviceTypeLabel[s.tip]}</TableCell>
                      <TableCell className="text-xs">{s.serviser ?? "—"}</TableCell>
                      <TableCell className="font-mono text-xs">{formatDate(s.datum)}</TableCell>
                      <TableCell className="font-mono text-xs">{s.kilometraza ? formatKm(s.kilometraza) : "—"}</TableCell>
                      <TableCell className="font-mono text-xs text-lime-300">{formatRSD(s.iznos)}</TableCell>
                      <TableCell><StatusPill status={s.status} /></TableCell>
                    </TableRow>
                  ))}
                  {data.servisi.length === 0 && (
                    <TableRow><TableCell colSpan={7} className="py-10 text-center text-zinc-500">Nema evidentiranih servisa.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="odrzavanje">
            <div className="grid gap-3 sm:grid-cols-2">
              {data.plan.map((p) => (
                <Card key={p.id}>
                  <CardHeader className="flex-row items-center justify-between space-y-0 p-4">
                    <CardTitle className="text-sm">{p.naslov}</CardTitle>
                    <StatusPill status={p.status} />
                  </CardHeader>
                  <CardContent className="space-y-1.5 p-4 pt-0 text-xs text-zinc-400">
                    <div>Interval: {p.intervalKm ? `${formatKm(p.intervalKm)}` : ""}{p.intervalKm && p.intervalDana ? " / " : ""}{p.intervalDana ? `${p.intervalDana} dana` : ""}{!p.intervalKm && !p.intervalDana ? "—" : ""}</div>
                    <div>Zadnje izvršeno: {formatDate(p.zadnjeIzvrseno)}</div>
                    <div>Status: {maintenanceStatusLabel[p.status]}</div>
                  </CardContent>
                </Card>
              ))}
              {data.plan.length === 0 && <p className="text-sm text-zinc-500">Nema planiranog održavanja.</p>}
            </div>
          </TabsContent>

          <TabsContent value="nalozi">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nalog</TableHead><TableHead>Relacija</TableHead><TableHead>Vozač</TableHead>
                    <TableHead>Polazak</TableHead><TableHead>Km</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.nalozi.map((n) => (
                    <TableRow key={n.id}>
                      <TableCell className="font-mono text-xs text-lime-300">{n.brojNaloga}</TableCell>
                      <TableCell className="font-medium text-zinc-100">{n.polaziste} → {n.odrediste}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <AvatarCircle initials={`${n.vozacIme[0]}${n.vozacPrezime[0]}`} className="h-7 w-7 text-[10px]" tone="sky" />
                          <span className="text-xs">{n.vozacIme} {n.vozacPrezime}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{formatDate(n.datumPolaska)}</TableCell>
                      <TableCell className="font-mono text-xs">{n.predjenoKm > 0 ? formatKm(n.predjenoKm) : "—"}</TableCell>
                      <TableCell><StatusPill status={n.status} /></TableCell>
                    </TableRow>
                  ))}
                  {data.nalozi.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="py-10 text-center text-zinc-500">Nema putnih naloga.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="gorivo">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="h-4 w-4 text-lime-300" />
                  Zadnjih {data.gorivo.length} točenja goriva
                </CardTitle>
                <CardDescription>Cijene u EUR po litri, iznosi u RSD</CardDescription>
              </CardHeader>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Datum</TableHead><TableHead>Pumpa</TableHead><TableHead>Litara</TableHead>
                    <TableHead>€/litar</TableHead><TableHead>Iznos</TableHead><TableHead>Km</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.gorivo.map((g) => (
                    <TableRow key={g.id}>
                      <TableCell className="font-mono text-xs">{formatDate(g.datum)}</TableCell>
                      <TableCell className="text-xs">{g.pumpa}</TableCell>
                      <TableCell className="font-mono text-xs">{Number(g.litara).toFixed(1)}</TableCell>
                      <TableCell className="font-mono text-xs">€{Number(g.cijenaPoLitri).toFixed(2)}</TableCell>
                      <TableCell className="font-mono text-xs text-lime-300">{formatRSD(g.ukupanIznos)}</TableCell>
                      <TableCell className="font-mono text-xs">{g.kilometraza ? formatKm(g.kilometraza) : "—"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>
        </Tabs>
        <Separator className="mt-8" />
        <p className="mt-4 text-center text-xs text-zinc-600">
          Detaljan karton vozila — svi podaci povezani u realnom vremenu.
        </p>
      </motion.div>
    </AppShell>
  );
}

"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CarFront, Plus, Search, FileCheck2, Gauge, Wrench } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { StatusPill } from "@/components/shared/status-pill";
import { VehicleVisual } from "@/components/shared/vehicle-visual";
import { useApi } from "@/components/shared/use-api";
import { apiSend } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Skeleton, Progress } from "@/components/ui/extras";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { formatKm, formatDate, daysUntil, expiryTone } from "@/lib/format";
import { fuelTypeLabel, vehicleTypeLabel } from "@/lib/labels";
import { cn } from "@/lib/utils";

type VehicleRow = {
  id: number;
  naziv: string;
  marka: string;
  model: string;
  tip: string;
  godiste: number;
  registracionaOznaka: string;
  gorivo: string;
  status: string;
  kilometraza: number;
  boja: string | null;
  regVaziDo: string | null;
  zadnjiServis: string | null;
  sledeciServisKm: number | null;
  brojNaloga: number;
};

const emptyForm = {
  naziv: "", marka: "", model: "", tip: "limuzina", godiste: String(new Date().getFullYear()),
  registracionaOznaka: "", brojSasije: "", gorivo: "dizel", kilometraza: "0", boja: "",
};

function AddVehicleDialog({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const set = (k: keyof typeof emptyForm) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    if (form.naziv.length < 2 || !form.registracionaOznaka || !form.brojSasije) {
      toast.error("Popuni naziv, registraciju i broj šasije");
      return;
    }
    setSaving(true);
    try {
      await apiSend("/api/vehicles", "POST", form);
      toast.success("Vozilo dodano u flotu");
      setOpen(false);
      setForm(emptyForm);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4" />
          Dodaj vozilo
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Novo vozilo</DialogTitle>
          <DialogDescription>Unesi osnovne podatke — registracije i servisi se dodaju naknadno.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Naziv vozila *</Label>
            <Input placeholder="npr. Passat B8 — Službeni" value={form.naziv} onChange={set("naziv")} />
          </div>
          <div className="space-y-1.5">
            <Label>Marka *</Label>
            <Input placeholder="Volkswagen" value={form.marka} onChange={set("marka")} />
          </div>
          <div className="space-y-1.5">
            <Label>Model *</Label>
            <Input placeholder="Passat 2.0 TDI" value={form.model} onChange={set("model")} />
          </div>
          <div className="space-y-1.5">
            <Label>Tip</Label>
            <Select value={form.tip} onValueChange={(v) => setForm((f) => ({ ...f, tip: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(vehicleTypeLabel).map(([val, lab]) => (
                  <SelectItem key={val} value={val}>{lab}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Godište</Label>
            <Input type="number" value={form.godiste} onChange={set("godiste")} />
          </div>
          <div className="space-y-1.5">
            <Label>Registraciona oznaka *</Label>
            <Input placeholder="BG 123-AB" value={form.registracionaOznaka} onChange={set("registracionaOznaka")} className="font-mono uppercase" />
          </div>
          <div className="space-y-1.5">
            <Label>Broj šasije (VIN) *</Label>
            <Input placeholder="WVWZZZ…" value={form.brojSasije} onChange={set("brojSasije")} className="font-mono uppercase" />
          </div>
          <div className="space-y-1.5">
            <Label>Gorivo</Label>
            <Select value={form.gorivo} onValueChange={(v) => setForm((f) => ({ ...f, gorivo: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(fuelTypeLabel).map(([val, lab]) => (
                  <SelectItem key={val} value={val}>{lab}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Kilometraža</Label>
            <Input type="number" value={form.kilometraza} onChange={set("kilometraza")} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>Otkaži</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Čuvanje…" : "Sačuvaj vozilo"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function VozilaPage() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("svi");
  const { data, loading, reload } = useApi<VehicleRow[]>("/api/vehicles", 60000);

  const filtered = useMemo(() => {
    if (!data) return [];
    return data.filter((v) => {
      const matchQ =
        !q ||
        `${v.naziv} ${v.marka} ${v.model} ${v.registracionaOznaka}`.toLowerCase().includes(q.toLowerCase());
      const matchS = status === "svi" || v.status === status;
      return matchQ && matchS;
    });
  }, [data, q, status]);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Vozni park"
        title="Vozila"
        description={`${data?.length ?? "…"} vozila u floti — pregled stanja, dokumenata i servisa.`}
        actions={<AddVehicleDialog onDone={() => reload(true)} />}
      />

      {/* Filteri */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mb-6 flex flex-col gap-3 sm:flex-row"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <Input
            placeholder="Pretraži po nazivu, marki ili registraciji…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="svi">Svi statusi</SelectItem>
            <SelectItem value="aktivno">Aktivno</SelectItem>
            <SelectItem value="servis">Na servisu</SelectItem>
            <SelectItem value="neaktivno">Neaktivno</SelectItem>
          </SelectContent>
        </Select>
      </motion.div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-80" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/10 py-24 text-center">
          <CarFront className="h-10 w-10 text-zinc-700" />
          <p className="text-zinc-500">Nema vozila koja odgovaraju pretrazi.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {filtered.map((v, i) => {
            const regDani = v.regVaziDo ? daysUntil(v.regVaziDo) : null;
            const tone = regDani != null ? expiryTone(regDani) : null;
            const doServisa = v.sledeciServisKm != null ? v.sledeciServisKm - v.kilometraza : null;
            const servisPct =
              doServisa != null ? Math.max(0, Math.min(100, (doServisa / 15000) * 100)) : null;

            return (
              <motion.div
                key={v.id}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.05 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
              >
                <Link href={`/vozila/${v.id}`}>
                  <div className="group relative overflow-hidden rounded-2xl border border-white/[0.07] bg-zinc-900/60 transition-all duration-300 hover:border-lime-400/30 hover:shadow-[0_20px_60px_-24px_rgba(163,230,53,0.35)] hover:-translate-y-1">
                    <VehicleVisual tip={v.tip} className="h-44" />
                    <div className="absolute left-3.5 top-3.5 rounded-lg border border-white/15 bg-zinc-950/85 px-2.5 py-1 font-mono text-xs font-semibold tracking-wider text-white backdrop-blur-sm">
                      {v.registracionaOznaka}
                    </div>
                    <div className="absolute right-3.5 top-3.5">
                      <StatusPill status={v.status} />
                    </div>

                    <div className="space-y-3.5 p-4">
                      <div>
                        <div className="font-semibold text-white group-hover:text-lime-200 transition-colors">
                          {v.naziv}
                        </div>
                        <div className="text-xs text-zinc-500">
                          {v.marka} {v.model} • {v.godiste}. • {fuelTypeLabel[v.gorivo]}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex items-center gap-1.5 rounded-lg bg-white/[0.03] px-2.5 py-1.5 text-zinc-300">
                          <Gauge className="h-3.5 w-3.5 text-zinc-500" />
                          {formatKm(v.kilometraza)}
                        </div>
                        <div className="flex items-center gap-1.5 rounded-lg bg-white/[0.03] px-2.5 py-1.5 text-zinc-300">
                          <Wrench className="h-3.5 w-3.5 text-zinc-500" />
                          {v.zadnjiServis ? formatDate(v.zadnjiServis) : "—"}
                        </div>
                      </div>

                      {regDani != null && (
                        <div
                          className={cn(
                            "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium",
                            tone === "danger" && "bg-red-400/10 text-red-300",
                            tone === "warning" && "bg-amber-400/10 text-amber-300",
                            tone === "ok" && "bg-emerald-400/10 text-emerald-300",
                          )}
                        >
                          <FileCheck2 className="h-3.5 w-3.5" />
                          {regDani < 0
                            ? `Registracija istekla prije ${-regDani} dana`
                            : `Registracija vrijedi još ${regDani} dana`}
                        </div>
                      )}

                      {servisPct != null && doServisa != null && (
                        <div>
                          <div className="mb-1.5 flex justify-between text-[10px] font-mono uppercase tracking-widest text-zinc-600">
                            <span>Do servisa</span>
                            <span className={doServisa < 1500 ? "text-amber-300" : ""}>
                              {doServisa > 0 ? `${formatKm(doServisa)}` : "dospio"}
                            </span>
                          </div>
                          <Progress
                            value={servisPct}
                            indicatorClassName={cn(
                              doServisa < 1500 ? "bg-amber-400" : "bg-lime-400",
                            )}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}

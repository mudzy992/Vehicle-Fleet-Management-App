"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Route, Play, CircleCheck, ArrowRight, MapPin } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { StatusPill } from "@/components/shared/status-pill";
import { useApi } from "@/components/shared/use-api";
import { apiSend } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton, AvatarCircle } from "@/components/ui/extras";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { formatRSD, formatKm, formatDateTime, initials } from "@/lib/format";
import { cn } from "@/lib/utils";

type TripRow = {
  id: number; brojNaloga: string; vehicleId: number; driverId: number;
  vozilo: string; oznaka: string; vozacIme: string; vozacPrezime: string;
  polaziste: string; odrediste: string; svrha: string | null;
  datumPolaska: string; datumDolaska: string | null;
  status: string; predjenoKm: number; troskovi: string; napomena: string | null;
};

type VehicleOpt = { id: number; naziv: string; registracionaOznaka: string };
type DriverOpt = { id: number; ime: string; prezime: string; status: string };

const STATUS_FILTERS = [
  { value: "svi", label: "Svi" },
  { value: "u_toku", label: "U toku" },
  { value: "planiran", label: "Planirani" },
  { value: "zavrsen", label: "Završeni" },
  { value: "otkazan", label: "Otkazani" },
];

function NewTripDialog({ vehicles, drivers, onDone }: { vehicles: VehicleOpt[]; drivers: DriverOpt[]; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    vehicleId: "", driverId: "", polaziste: "", odrediste: "", svrha: "",
    datumPolaska: "", troskovi: "", napomena: "",
  });

  const submit = async () => {
    if (!form.vehicleId || !form.driverId || !form.polaziste || !form.odrediste || !form.datumPolaska) {
      toast.error("Vozilo, vozač, relacija i datum polaska su obavezni");
      return;
    }
    setSaving(true);
    try {
      await apiSend("/api/trips", "POST", {
        vehicleId: Number(form.vehicleId),
        driverId: Number(form.driverId),
        polaziste: form.polaziste,
        odrediste: form.odrediste,
        svrha: form.svrha || undefined,
        datumPolaska: form.datumPolaska,
        troskovi: form.troskovi ? Number(form.troskovi) : 0,
        napomena: form.napomena || undefined,
      });
      toast.success("Putni nalog kreiran");
      setOpen(false);
      setForm({ vehicleId: "", driverId: "", polaziste: "", odrediste: "", svrha: "", datumPolaska: "", troskovi: "", napomena: "" });
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4" /> Novi putni nalog</Button>
      </DialogTrigger>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Novi putni nalog</DialogTitle>
          <DialogDescription>Broj naloga se generiše automatski.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Vozilo *</Label>
            <Select value={form.vehicleId} onValueChange={(v) => setForm((f) => ({ ...f, vehicleId: v }))}>
              <SelectTrigger><SelectValue placeholder="Izaberi…" /></SelectTrigger>
              <SelectContent>
                {vehicles.map((v) => (
                  <SelectItem key={v.id} value={String(v.id)}>{v.naziv} ({v.registracionaOznaka})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Vozač *</Label>
            <Select value={form.driverId} onValueChange={(v) => setForm((f) => ({ ...f, driverId: v }))}>
              <SelectTrigger><SelectValue placeholder="Izaberi…" /></SelectTrigger>
              <SelectContent>
                {drivers.map((d) => (
                  <SelectItem key={d.id} value={String(d.id)}>{d.ime} {d.prezime}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Polazište *</Label>
            <Input placeholder="Beograd" value={form.polaziste} onChange={(e) => setForm((f) => ({ ...f, polaziste: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Odredište *</Label>
            <Input placeholder="Zagreb" value={form.odrediste} onChange={(e) => setForm((f) => ({ ...f, odrediste: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Datum polaska *</Label>
            <Input type="datetime-local" value={form.datumPolaska} onChange={(e) => setForm((f) => ({ ...f, datumPolaska: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Predviđeni troškovi (RSD)</Label>
            <Input type="number" placeholder="12000" value={form.troskovi} onChange={(e) => setForm((f) => ({ ...f, troskovi: e.target.value }))} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Svrha putovanja</Label>
            <Input placeholder="Sastanak sa klijentom…" value={form.svrha} onChange={(e) => setForm((f) => ({ ...f, svrha: e.target.value }))} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Napomena</Label>
            <Textarea value={form.napomena} onChange={(e) => setForm((f) => ({ ...f, napomena: e.target.value }))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>Otkaži</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Kreiranje…" : "Kreiraj nalog"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function FinishTripAction({ trip, onDone }: { trip: TripRow; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [km, setKm] = useState("");
  const [saving, setSaving] = useState(false);

  const finish = async () => {
    if (!km) {
      toast.error("Unesi pređenu kilometražu");
      return;
    }
    setSaving(true);
    try {
      await apiSend(`/api/trips/${trip.id}`, "PATCH", { status: "zavrsen", predjenoKm: Number(km) });
      toast.success("Nalog završen — kilometraža vozila ažurirana");
      setOpen(false);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Button size="sm" onClick={() => setOpen(true)}>
        <CircleCheck className="h-3.5 w-3.5" /> Završi
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Završi nalog {trip.brojNaloga}</DialogTitle>
            <DialogDescription>Unesi ukupno pređene kilometre. Kilometraža vozila se ažurira automatski.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label>Pređeno kilometara</Label>
            <Input type="number" placeholder="npr. 392" value={km} onChange={(e) => setKm(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setOpen(false)}>Otkaži</Button>
            <Button onClick={finish} disabled={saving}>{saving ? "…" : "Potvrdi"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

const TONES = ["lime", "sky", "amber", "rose", "violet"] as const;

export default function PutniNaloziPage() {
  const [filter, setFilter] = useState("svi");
  const { data, loading, reload } = useApi<TripRow[]>("/api/trips", 45000);
  const { data: vozila } = useApi<VehicleOpt[]>("/api/vehicles");
  const { data: vozaci } = useApi<DriverOpt[]>("/api/drivers");

  const filtered = useMemo(
    () => (data ?? []).filter((t) => filter === "svi" || t.status === filter),
    [data, filter],
  );

  const startTrip = async (id: number) => {
    try {
      await apiSend(`/api/trips/${id}`, "PATCH", { status: "u_toku" });
      toast.success("Nalog pokrenut");
      reload(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    }
  };

  const cancelTrip = async (id: number) => {
    try {
      await apiSend(`/api/trips/${id}`, "PATCH", { status: "otkazan" });
      toast.success("Nalog otkazan");
      reload(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    }
  };

  return (
    <AppShell>
      <PageHeader
        eyebrow="Operacije"
        title="Putni nalozi"
        description="Digitalni nalozi sa relacijama, vozačima, troškovima i kilometražom."
        actions={<NewTripDialog vehicles={vozila ?? []} drivers={vozaci ?? []} onDone={() => reload(true)} />}
      />

      {/* Filteri */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.05 }}
        className="mb-6 flex flex-wrap gap-2"
      >
        {STATUS_FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={cn(
              "rounded-xl border px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer",
              filter === f.value
                ? "border-lime-400/60 bg-lime-400/15 text-lime-200 shadow-[0_0_20px_-6px_rgba(163,230,53,0.5)]"
                : "border-white/[0.08] bg-white/[0.02] text-zinc-500 hover:border-white/20 hover:text-zinc-300",
            )}
          >
            {f.label}
          </button>
        ))}
      </motion.div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-28" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-white/10 py-24 text-center text-zinc-500">
          <Route className="h-10 w-10 text-zinc-700" />
          Nema naloga za izabrani filter.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: i * 0.04 }}
            >
              <Card className={cn(
                "overflow-hidden transition-all duration-300 hover:border-white/[0.15]",
                t.status === "u_toku" && "border-amber-400/30 shadow-[0_0_40px_-18px_rgba(251,191,36,0.4)]",
              )}>
                <CardContent className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center">
                  {/* Relacija */}
                  <div className="flex min-w-0 flex-1 items-center gap-4">
                    <div className={cn(
                      "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border",
                      t.status === "u_toku" ? "border-amber-400/30 bg-amber-400/10 text-amber-300" : "border-lime-400/25 bg-lime-400/10 text-lime-300",
                    )}>
                      <Route className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-lg font-semibold text-white">
                        <span className="truncate">{t.polaziste}</span>
                        <ArrowRight className="h-4 w-4 shrink-0 text-lime-300" />
                        <span className="truncate">{t.odrediste}</span>
                      </div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-zinc-500">
                        <span className="font-mono text-lime-300/80">{t.brojNaloga}</span>
                        {t.svrha && <span className="truncate">• {t.svrha}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Meta */}
                  <div className="grid flex-shrink-0 grid-cols-2 gap-x-8 gap-y-2 text-xs sm:grid-cols-4 lg:text-left">
                    <div>
                      <div className="text-[9px] font-mono uppercase tracking-widest text-zinc-600">Vozilo</div>
                      <div className="mt-0.5 flex items-center gap-1.5 font-medium text-zinc-200">
                        <MapPin className="h-3 w-3 text-zinc-600" />
                        <span className="max-w-32 truncate">{t.vozilo}</span>
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] font-mono uppercase tracking-widest text-zinc-600">Vozač</div>
                      <div className="mt-0.5 flex items-center gap-1.5 font-medium text-zinc-200">
                        <AvatarCircle initials={initials(t.vozacIme, t.vozacPrezime)} tone={TONES[t.driverId % TONES.length]} className="h-5 w-5 text-[8px]" />
                        {t.vozacIme} {t.vozacPrezime}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] font-mono uppercase tracking-widest text-zinc-600">Polazak</div>
                      <div className="mt-0.5 font-mono text-zinc-200">{formatDateTime(t.datumPolaska)}</div>
                    </div>
                    <div>
                      <div className="text-[9px] font-mono uppercase tracking-widest text-zinc-600">Km / Troškovi</div>
                      <div className="mt-0.5 font-mono text-zinc-200">
                        {t.predjenoKm > 0 ? formatKm(t.predjenoKm) : "—"} / {formatRSD(t.troskovi)}
                      </div>
                    </div>
                  </div>

                  {/* Akcije */}
                  <div className="flex shrink-0 items-center gap-2">
                    <StatusPill status={t.status} />
                    {t.status === "planiran" && (
                      <Button size="sm" variant="secondary" onClick={() => startTrip(t.id)}>
                        <Play className="h-3.5 w-3.5" /> Pokreni
                      </Button>
                    )}
                    {t.status === "u_toku" && <FinishTripAction trip={t} onDone={() => reload(true)} />}
                    {t.status === "planiran" && (
                      <Button size="sm" variant="ghost" className="text-zinc-500 hover:text-red-300" onClick={() => cancelTrip(t.id)}>
                        Otkaži
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

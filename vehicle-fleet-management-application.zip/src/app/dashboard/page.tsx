"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Car,
  Route,
  Fuel,
  AlertTriangle,
  ArrowUpRight,
  FileCheck2,
  IdCard,
  Wrench,
  CalendarClock,
  ChevronRight,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { CountUp } from "@/components/shared/count-up";
import { StatusPill } from "@/components/shared/status-pill";
import { CostTrendChart, FleetCostChart, FleetStatusDonut } from "@/components/shared/charts";
import { LiveMap, type MapVehicle } from "@/components/shared/live-map";
import { useApi } from "@/components/shared/use-api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/extras";
import { formatRSD, formatKm, formatDate, daysUntil } from "@/lib/format";

type DashData = {
  kpi: {
    vozilaUkupno: number;
    vozilaAktivna: number;
    vozilaServis: number;
    ukupnoKm: number;
    vozaciAktivni: number;
    vozaciUkupno: number;
    naloziUToku: number;
    naloziPlanirani: number;
    kmOvajMjesec: number;
    gorivoMjesec: number;
    litaraMjesec: number;
    servisiMjesec: number;
    aktivnihServisa: number;
    alerta: number;
  };
  troskoviTrend: { mjesec: string; gorivo: number; servisi: number }[];
  troskoviPoVozilu: { naziv: string; gorivo: number; servisi: number }[];
  alerti: {
    registracije: { id: number; vozilo: string; oznaka: string; vaziDo: string }[];
    vozacke: { id: number; ime: string; prezime: string; vaziDo: string }[];
    odrzavanje: { id: number; vozilo: string; naslov: string; status: string }[];
    servisi: { id: number; vozilo: string; naziv: string; datum: string; status: string }[];
  };
  nedavniNalozi: {
    id: number;
    brojNaloga: string;
    polaziste: string;
    odrediste: string;
    status: string;
    datumPolaska: string;
    predjenoKm: number;
    vozilo: string;
    vozacIme: string;
    vozacPrezime: string;
  }[];
  zadnjeLokacije: MapVehicle[];
};

const EASE = [0.22, 1, 0.36, 1] as const;

function KpiCard({
  href,
  icon: Icon,
  label,
  value,
  suffix,
  sub,
  tone = "lime",
  delay = 0,
}: {
  href: string;
  icon: React.ElementType;
  label: string;
  value: number;
  suffix?: string;
  sub: string;
  tone?: "lime" | "sky" | "amber" | "rose";
  delay?: number;
}) {
  const tones = {
    lime: "text-lime-300 border-lime-400/25 bg-lime-400/10",
    sky: "text-sky-300 border-sky-400/25 bg-sky-400/10",
    amber: "text-amber-300 border-amber-400/25 bg-amber-400/10",
    rose: "text-rose-300 border-rose-400/25 bg-rose-400/10",
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: EASE }}
    >
      <Link href={href}>
        <Card className="group relative overflow-hidden transition-all duration-300 hover:border-white/[0.14] hover:-translate-y-0.5">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div className={`flex h-11 w-11 items-center justify-center rounded-xl border ${tones[tone]}`}>
                <Icon className="h-5 w-5" />
              </div>
              <ArrowUpRight className="h-4 w-4 text-zinc-600 transition-all group-hover:text-lime-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
            <div className="mt-5 text-3xl font-bold tracking-tight text-white">
              <CountUp value={value} suffix={suffix} />
            </div>
            <div className="mt-1 text-xs font-medium text-zinc-400">{label}</div>
            <div className="mt-2 font-mono text-[10px] uppercase tracking-widest text-zinc-600">{sub}</div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}

export default function DashboardPage() {
  const { data, loading } = useApi<DashData>("/api/dashboard", 30000);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Kontrolni centar"
        title="Pregled flote"
        description="Stanje cijelog voznog parka u realnom vremenu — troškovi, alerti, nalozi i lokacije."
      />

      {/* KPI red */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {loading || !data ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-40" />)
        ) : (
          <>
            <KpiCard href="/vozila" icon={Car} label="aktivnih vozila" value={data.kpi.vozilaAktivna} sub={`${data.kpi.vozilaUkupno} ukupno • ${data.kpi.vozilaServis} na servisu`} tone="lime" delay={0} />
            <KpiCard href="/putni-nalozi" icon={Route} label="km pređeno ovog mjeseca" value={data.kpi.kmOvajMjesec} sub={`${data.kpi.naloziUToku} u toku • ${data.kpi.naloziPlanirani} planirano`} tone="sky" delay={0.06} />
            <KpiCard href="/servisi" icon={Fuel} label="RSD gorivo ovog mjeseca" value={data.kpi.gorivoMjesec} sub={`${Math.round(data.kpi.litaraMjesec)} litara ukupno`} tone="amber" delay={0.12} />
            <KpiCard href="/registracije" icon={AlertTriangle} label="aktivnih upozorenja" value={data.kpi.alerta} sub="registracije • dozvole • održavanje" tone="rose" delay={0.18} />
          </>
        )}
      </div>

      {/* Grafovi */}
      <div className="mt-6 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.22, ease: EASE }}
          className="xl:col-span-2"
        >
          <Card className="h-full">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Trend troškova</CardTitle>
                <CardDescription>Gorivo + servisi po mjesecu</CardDescription>
              </div>
              <div className="rounded-lg border border-white/[0.08] bg-zinc-950/60 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-zinc-500">
                6 mjeseci
              </div>
            </CardHeader>
            <CardContent>
              {loading || !data ? <Skeleton className="h-[280px]" /> : <CostTrendChart data={data.troskoviTrend} />}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.28, ease: EASE }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Status flote</CardTitle>
              <CardDescription>Raspodjela vozila po statusu</CardDescription>
            </CardHeader>
            <CardContent>
              {loading || !data ? (
                <Skeleton className="h-[210px]" />
              ) : (
                <>
                  <FleetStatusDonut
                    aktivna={data.kpi.vozilaAktivna}
                    servis={data.kpi.vozilaServis}
                    neaktivna={data.kpi.vozilaUkupno - data.kpi.vozilaAktivna - data.kpi.vozilaServis}
                  />
                  <div className="mt-2 grid grid-cols-2 gap-2 border-t border-white/[0.06] pt-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-white">{formatKm(data.kpi.ukupnoKm).replace(" km", "")}</div>
                      <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">ukupno km</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-white">{data.kpi.vozaciAktivni}/{data.kpi.vozaciUkupno}</div>
                      <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">vozača aktivno</div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Mapa + Alerti */}
      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.32, ease: EASE }}
          className="xl:col-span-2"
        >
          <Card className="h-full overflow-hidden">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Lokacije uživo</CardTitle>
                <CardDescription>GPS telemetrija cijele flote</CardDescription>
              </div>
              <Link href="/lokacije" className="flex items-center gap-1 text-xs font-medium text-lime-300 hover:underline">
                Puni prikaz <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              {loading || !data ? (
                <Skeleton className="h-[340px]" />
              ) : (
                <LiveMap latest={data.zadnjeLokacije} trails={[]} className="h-[340px]" interactive={false} />
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Alerti */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.36, ease: EASE }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-rose-300" />
                Upozorenja
              </CardTitle>
              <CardDescription>Zahtijevaju pažnju u narednih 30 dana</CardDescription>
            </CardHeader>
            <CardContent className="max-h-[400px] space-y-2.5 overflow-y-auto">
              {loading || !data ? (
                Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14" />)
              ) : (
                <>
                  {data.alerti.registracije.map((r) => {
                    const dani = daysUntil(r.vaziDo);
                    return (
                      <div key={`reg-${r.id}`} className="flex items-center gap-3 rounded-xl border border-red-400/20 bg-red-400/[0.06] p-3">
                        <FileCheck2 className="h-4 w-4 shrink-0 text-red-300" />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium text-zinc-200">{r.vozilo}</div>
                          <div className="text-xs text-zinc-500">
                            Registracija {dani < 0 ? `istekla prije ${-dani}d` : `ističe za ${dani}d`}
                          </div>
                        </div>
                        <span className="font-mono text-[10px] text-red-300">{formatDate(r.vaziDo)}</span>
                      </div>
                    );
                  })}
                  {data.alerti.vozacke.map((v) => {
                    const dani = daysUntil(v.vaziDo);
                    return (
                      <div key={`drv-${v.id}`} className="flex items-center gap-3 rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3">
                        <IdCard className="h-4 w-4 shrink-0 text-amber-300" />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium text-zinc-200">{v.ime} {v.prezime}</div>
                          <div className="text-xs text-zinc-500">
                            Vozačka {dani < 0 ? `istekla prije ${-dani}d` : `ističe za ${dani}d`}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {data.alerti.odrzavanje.map((o) => (
                    <div key={`mnt-${o.id}`} className="flex items-center gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] p-3">
                      <Wrench className={`h-4 w-4 shrink-0 ${o.status === "isteklo" ? "text-red-300" : "text-sky-300"}`} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-zinc-200">{o.naslov}</div>
                        <div className="text-xs text-zinc-500">{o.vozilo}</div>
                      </div>
                      <StatusPill status={o.status} />
                    </div>
                  ))}
                  {data.alerti.servisi.slice(0, 3).map((s) => (
                    <div key={`srv-${s.id}`} className="flex items-center gap-3 rounded-xl border border-sky-400/20 bg-sky-400/[0.05] p-3">
                      <CalendarClock className="h-4 w-4 shrink-0 text-sky-300" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-zinc-200">{s.naziv}</div>
                        <div className="text-xs text-zinc-500">{s.vozilo} • {formatDate(s.datum)}</div>
                      </div>
                      <StatusPill status={s.status} />
                    </div>
                  ))}
                  {data.kpi.alerta === 0 && (
                    <div className="py-10 text-center text-sm text-zinc-500">
                      Sve pod kontrolom — nema aktivnih upozorenja.
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Troškovi po vozilu + nedavni nalozi */}
      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-5">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4, ease: EASE }}
          className="xl:col-span-3"
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Troškovi po vozilu</CardTitle>
              <CardDescription>Ukupno gorivo i servisi (RSD)</CardDescription>
            </CardHeader>
            <CardContent>
              {loading || !data ? <Skeleton className="h-[280px]" /> : <FleetCostChart data={data.troskoviPoVozilu} />}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.44, ease: EASE }}
          className="xl:col-span-2"
        >
          <Card className="h-full">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Nedavni putni nalozi</CardTitle>
                <CardDescription>Zadnjih 6 naloga</CardDescription>
              </div>
              <Link href="/putni-nalozi" className="flex items-center gap-1 text-xs font-medium text-lime-300 hover:underline">
                Svi nalozi <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </CardHeader>
            <CardContent className="space-y-2">
              {loading || !data ? (
                Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14" />)
              ) : (
                data.nedavniNalozi.map((n) => (
                  <div key={n.id} className="group flex items-center gap-3 rounded-xl border border-white/[0.05] bg-white/[0.02] p-3 transition-colors hover:border-lime-400/25">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-sm font-medium text-zinc-200">
                        <span className="truncate">{n.polaziste}</span>
                        <ArrowUpRight className="h-3 w-3 shrink-0 text-zinc-600 group-hover:text-lime-300" />
                        <span className="truncate">{n.odrediste}</span>
                      </div>
                      <div className="mt-0.5 font-mono text-[10px] uppercase tracking-widest text-zinc-600">
                        {n.brojNaloga} • {n.vozacIme} {n.vozacPrezime} • {formatDate(n.datumPolaska)}
                      </div>
                    </div>
                    <StatusPill status={n.status} />
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </AppShell>
  );
}

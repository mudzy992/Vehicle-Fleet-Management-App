"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { FileCheck2, RefreshCw, ShieldAlert, ShieldCheck, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { VehicleVisual } from "@/components/shared/vehicle-visual";
import { useApi } from "@/components/shared/use-api";
import { apiSend } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/extras";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { formatRSD, formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

type RegRow = {
  id: number;
  vehicleId: number;
  vozilo: string;
  oznaka: string;
  slikaTip: string;
  datumRegistracije: string;
  vaziDo: string;
  brojPolice: string | null;
  osiguravajucaKuca: string | null;
  iznos: string;
  placeno: boolean;
  danaPreostalo: number;
};

function toneClass(dani: number) {
  if (dani < 0) return { ring: "border-red-400/40", badge: "bg-red-400/15 text-red-300", label: "ISTEKLA", glow: "hover:shadow-[0_20px_60px_-24px_rgba(248,113,113,0.45)]" };
  if (dani <= 30) return { ring: "border-amber-400/40", badge: "bg-amber-400/15 text-amber-300", label: "ISTIČE USKORO", glow: "hover:shadow-[0_20px_60px_-24px_rgba(251,191,36,0.4)]" };
  return { ring: "border-white/[0.07]", badge: "bg-emerald-400/10 text-emerald-300", label: "VAŽEĆA", glow: "hover:shadow-[0_20px_60px_-24px_rgba(163,230,53,0.3)]" };
}

export default function RegistracijePage() {
  const { data, loading, reload } = useApi<RegRow[]>("/api/registracije", 60000);
  const [renewFor, setRenewFor] = useState<RegRow | null>(null);
  const [saving, setSaving] = useState(false);
  const [renewForm, setRenewForm] = useState({ vaziDo: "", iznos: "", osiguravajucaKuca: "" });

  const openRenew = (r: RegRow) => {
    const next = new Date();
    next.setFullYear(next.getFullYear() + 1);
    setRenewForm({
      vaziDo: next.toISOString().slice(0, 10),
      iznos: String(Math.round(Number(r.iznos))),
      osiguravajucaKuca: r.osiguravajucaKuca ?? "",
    });
    setRenewFor(r);
  };

  const submitRenew = async () => {
    if (!renewFor) return;
    setSaving(true);
    try {
      await apiSend("/api/registrations", "POST", {
        vehicleId: renewFor.vehicleId,
        datumRegistracije: new Date().toISOString().slice(0, 10),
        vaziDo: renewForm.vaziDo,
        iznos: Number(renewForm.iznos || 0),
        osiguravajucaKuca: renewForm.osiguravajucaKuca || undefined,
        brojPolice: `POL-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 89999)}`,
        placeno: true,
      });
      toast.success(`Registracija obnovljena za ${renewFor.vozilo}`);
      setRenewFor(null);
      reload(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Greška");
    } finally {
      setSaving(false);
    }
  };

  const istekle = data?.filter((r) => r.danaPreostalo < 0).length ?? 0;
  const kritino = data?.filter((r) => r.danaPreostalo >= 0 && r.danaPreostalo <= 30).length ?? 0;
  const uredu = data?.filter((r) => r.danaPreostalo > 30).length ?? 0;

  return (
    <AppShell>
      <PageHeader
        eyebrow="Dokumentacija"
        title="Registracije"
        description="Praćenje važenja registracija i polisa osiguranja sa odbrojavanjem."
      />

      {/* Stat strip */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.05 }}
        className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3"
      >
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-red-400/25 bg-red-400/10">
              <ShieldAlert className="h-5 w-5 text-red-300" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{loading ? "…" : istekle}</div>
              <div className="text-xs text-zinc-500">isteklih registracija</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-400/25 bg-amber-400/10">
              <AlertTriangle className="h-5 w-5 text-amber-300" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{loading ? "…" : kritino}</div>
              <div className="text-xs text-zinc-500">ističe u narednih 30 dana</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-400/10">
              <ShieldCheck className="h-5 w-5 text-emerald-300" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{loading ? "…" : uredu}</div>
              <div className="text-xs text-zinc-500">važećih bez brige</div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-72" />)}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {data?.map((r, i) => {
            const t = toneClass(r.danaPreostalo);
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
              >
                <div className={cn("group overflow-hidden rounded-2xl border bg-zinc-900/60 transition-all duration-300 hover:-translate-y-0.5", t.ring, t.glow)}>
                  <VehicleVisual tip={r.slikaTip} className="h-28" />
                  <div className="relative p-5 pt-3">
                    <div className="absolute -top-5 right-4 rounded-xl border border-white/15 bg-zinc-950 px-3 py-1.5 font-mono text-xs font-bold tracking-widest text-white shadow-lg">
                      {r.oznaka}
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-semibold text-white">{r.vozilo}</div>
                      <span className={cn("rounded-full px-2.5 py-1 text-[10px] font-mono font-semibold tracking-widest", t.badge)}>
                        {t.label}
                      </span>
                    </div>

                    <div className="mt-4 space-y-2 text-xs text-zinc-400">
                      <div className="flex justify-between">
                        <span>Registrovano</span>
                        <span className="font-mono text-zinc-200">{formatDate(r.datumRegistracije)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Važi do</span>
                        <span className="font-mono text-zinc-200">{formatDate(r.vaziDo)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Osiguranje</span>
                        <span>{r.osiguravajucaKuca ?? "—"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Polisa</span>
                        <span className="font-mono">{r.brojPolice ?? "—"}</span>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-white/[0.06] pt-4">
                      <div>
                        <div className={cn("text-2xl font-bold", r.danaPreostalo < 0 ? "text-red-300" : r.danaPreostalo <= 30 ? "text-amber-300" : "text-white")}>
                          {r.danaPreostalo < 0 ? -r.danaPreostalo : r.danaPreostalo}
                          <span className="ml-1 text-xs font-medium text-zinc-500">
                            {r.danaPreostalo < 0 ? "d prekoračeno" : "dana"}
                          </span>
                        </div>
                        <div className="text-[10px] font-mono uppercase tracking-widest text-zinc-600">
                          {formatRSD(r.iznos)} {!r.placeno && "• neplaćeno"}
                        </div>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => openRenew(r)}>
                        <RefreshCw className="h-3.5 w-3.5" />
                        Obnovi
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
      {data && data.length === 0 && (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-white/10 py-24 text-center text-zinc-500">
          <FileCheck2 className="h-10 w-10 text-zinc-700" />
          Nema evidentiranih registracija.
        </div>
      )}

      <Dialog open={renewFor != null} onOpenChange={(o) => !o && setRenewFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Obnova registracije</DialogTitle>
            <DialogDescription>
              {renewFor?.vozilo} ({renewFor?.oznaka}) — nova godišnja registracija.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Važi do</Label>
              <Input type="date" value={renewForm.vaziDo} onChange={(e) => setRenewForm((f) => ({ ...f, vaziDo: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Iznos (RSD)</Label>
              <Input type="number" value={renewForm.iznos} onChange={(e) => setRenewForm((f) => ({ ...f, iznos: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Osiguravajuća kuća</Label>
              <Input value={renewForm.osiguravajucaKuca} onChange={(e) => setRenewForm((f) => ({ ...f, osiguravajucaKuca: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setRenewFor(null)}>Otkaži</Button>
            <Button onClick={submitRenew} disabled={saving}>{saving ? "Čuvanje…" : "Potvrdi obnovu"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

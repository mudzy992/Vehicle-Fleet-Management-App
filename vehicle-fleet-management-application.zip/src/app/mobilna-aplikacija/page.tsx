"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Smartphone, Terminal, Copy, Check, Wifi, Database, ShieldCheck,
  BellRing, ArrowRight, Sparkles,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const ENDPOINTS: { method: string; path: string; desc: string; tag: string }[] = [
  { method: "GET", path: "/api/dashboard", desc: "KPI, trendovi, alerti, zadnje lokacije — sve za početni ekran app", tag: "core" },
  { method: "GET", path: "/api/vehicles", desc: "Lista vozila (q, status filteri)", tag: "vozila" },
  { method: "POST", path: "/api/vehicles", desc: "Dodavanje novog vozila", tag: "vozila" },
  { method: "GET", path: "/api/vehicles/:id", desc: "Detaljan karton: servisi, registracije, nalozi, gorivo", tag: "vozila" },
  { method: "GET", path: "/api/drivers", desc: "Lista vozača sa statistikom", tag: "vozači" },
  { method: "POST", path: "/api/drivers", desc: "Dodavanje vozača", tag: "vozači" },
  { method: "GET", path: "/api/trips", desc: "Putni nalozi (status filter)", tag: "nalozi" },
  { method: "POST", path: "/api/trips", desc: "Kreiranje naloga — broj se generiše automatski", tag: "nalozi" },
  { method: "PATCH", path: "/api/trips/:id", desc: "Pokreni / završi nalog + prijava kilometraže", tag: "nalozi" },
  { method: "GET", path: "/api/services", desc: "Servisna istorija i zakazani servisi", tag: "servisi" },
  { method: "POST", path: "/api/services", desc: "Evidentiranje servisa", tag: "servisi" },
  { method: "GET", path: "/api/registrations", desc: "Registracije sa preostalim danima", tag: "docs" },
  { method: "GET", path: "/api/locations", desc: "GPS pozicije i tragovi kretanja", tag: "gps" },
  { method: "GET", path: "/api/fuel-logs", desc: "Evidencija točenja goriva", tag: "gorivo" },
];

const METHOD_STYLE: Record<string, string> = {
  GET: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  POST: "border-sky-400/30 bg-sky-400/10 text-sky-300",
  PATCH: "border-amber-400/30 bg-amber-400/10 text-amber-300",
};

const EXPO_CLIENT = `// lib/api.ts — tipizirani klijent za Expo aplikaciju
const API_URL = process.env.EXPO_PUBLIC_API_URL; // npr. https://flota.tvojafirma.rs

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(\`\${API_URL}\${path}\`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) throw new Error(\`API \${res.status}: \${path}\`);
  return res.json();
}

export const getVehicles = () => api<Vehicle[]>("/api/vehicles");
export const getTrips    = () => api<Trip[]>("/api/trips");
export const finishTrip  = (id: number, km: number) =>
  api<Trip>(\`/api/trips/\${id}\`, {
    method: "PATCH",
    body: JSON.stringify({ status: "zavrsen", predjenoKm: km }),
  });`;

const STEPS = [
  { cmd: "npx create-expo-app@latest flota-mobile", desc: "Kreiraj Expo projekt (SDK 52+)" },
  { cmd: "cd flota-mobile && npx expo install expo-notifications expo-location", desc: "Push obavještenja + GPS modul" },
  { cmd: "echo 'EXPO_PUBLIC_API_URL=https://flota.tvojafirma.rs' > .env", desc: 'Uperi app na isti backend koji pokreće ovu web aplikaciju' },
  { cmd: "npx expo start", desc: "Skeniraj QR kod sa Expo Go — gotovo" },
];

const TREE = `flota-mobile/
├── app/                  # Expo Router ekrani
│   ├── (tabs)/
│   │   ├── index.tsx     # Početna — aktivan nalog + KPI
│   │   ├── vozila.tsx    # Lista vozila
│   │   ├── nalozi.tsx    # Putni nalozi
│   │   └── profil.tsx    # Karton vozača
│   └── nalog/[id].tsx    # Detalj + završetak naloga
├── lib/
│   ├── api.ts            # Tipizirani klijent (isporučen desno)
│   └── types.ts          # Dijeljeni tipovi sa backendom
└── assets/               # Ikonice, splash
`;

function CodeBlock({ code, title }: { code: string; title: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-zinc-950">
      <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-2.5">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-lime-400/70" />
          <span className="ml-2 font-mono text-[10px] text-zinc-500">{title}</span>
        </div>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 rounded-lg border border-white/10 px-2.5 py-1 text-[10px] font-medium text-zinc-400 transition-colors hover:border-lime-400/40 hover:text-lime-300 cursor-pointer"
        >
          {copied ? <Check className="h-3 w-3 text-lime-300" /> : <Copy className="h-3 w-3" />}
          {copied ? "Kopirano" : "Kopiraj"}
        </button>
      </div>
      <pre className="max-h-[420px] overflow-auto p-4 font-mono text-[11.5px] leading-relaxed text-zinc-300">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export default function MobilnaAplikacijaPage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="React Native + Expo"
        title="Mobilna aplikacija"
        description="Priprema za Expo app koja troši isti production backend — bez dupliranja logike."
      />

      {/* Pregled */}
      <div className="grid gap-4 lg:grid-cols-3">
        {[
          { icon: Wifi, title: "Jedan backend", desc: "Expo app pogađa iste REST rute kao i ova web aplikacija. Nula duplicirane logike, jedan PostgreSQL izvor istine." },
          { icon: Database, title: "Tipizirani ugovori", desc: "Tipovi iz Drizzle šeme su ugovor sa mobilnom app — kopiraj ih u lib/types.ts i dobijaš potpunu autocompletion." },
          { icon: BellRing, title: "Terenske notifikacije", desc: "Expo push za istek registracija, zakazane servise i nove putne naloge — direktno vozaču u džep." },
        ].map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
          >
            <Card className="h-full transition-colors hover:border-lime-400/30">
              <CardContent className="p-5">
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl border border-lime-400/25 bg-lime-400/10">
                  <f.icon className="h-5 w-5 text-lime-300" />
                </div>
                <div className="mb-1.5 font-semibold text-white">{f.title}</div>
                <p className="text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Koraci */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="mt-8"
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-lime-300" />
              Pokretanje za 4 koraka
            </CardTitle>
            <CardDescription>Od nule do aplikacije na telefonu za manje od 5 minuta.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {STEPS.map((s, i) => (
              <div key={s.cmd} className="flex items-start gap-4 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-lime-400 font-mono text-xs font-bold text-zinc-950">
                  {i + 1}
                </span>
                <div className="min-w-0">
                  <code className="block overflow-x-auto whitespace-nowrap font-mono text-xs text-lime-200">{s.cmd}</code>
                  <span className="mt-1 block text-xs text-zinc-500">{s.desc}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Kod + struktura */}
      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.28 }}>
          <CodeBlock title="lib/api.ts — spreman klijent" code={EXPO_CLIENT} />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.34 }}>
          <CodeBlock title="Struktura Expo projekta" code={TREE} />
        </motion.div>
      </div>

      {/* API referenca */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="mt-4"
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-lime-300" />
              REST API referenca
            </CardTitle>
            <CardDescription>Sve rute dostupne mobilnoj aplikaciji — JSON odgovori, zod validacija ulaza.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2 md:grid-cols-2">
            {ENDPOINTS.map((e) => (
              <div key={e.method + e.path} className="flex items-center gap-3 rounded-xl border border-white/[0.05] bg-white/[0.02] px-3.5 py-2.5">
                <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] font-bold ${METHOD_STYLE[e.method]}`}>
                  {e.method}
                </span>
                <div className="min-w-0">
                  <code className="block truncate font-mono text-xs text-zinc-200">{e.path}</code>
                  <span className="block truncate text-[11px] text-zinc-500">{e.desc}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Napomene za produkciju */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.46 }}
        className="mt-4"
      >
        <Card className="border-amber-400/20 bg-amber-400/[0.03]">
          <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-amber-400/30 bg-amber-400/10">
              <ShieldCheck className="h-5 w-5 text-amber-300" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 font-semibold text-white">
                Produkcijski checklist
                <Badge variant="warning">prije objave</Badge>
              </div>
              <div className="mt-1 flex flex-wrap gap-x-6 gap-y-1 text-sm text-zinc-400">
                <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-lime-300" /> Token auth (Bearer) na API rutama</span>
                <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-lime-300" /> Rate limiting — /api/locations</span>
                <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-lime-300" /> EAS Build profili (dev / prod)</span>
                <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-lime-300" /> Sentry crash reporting</span>
              </div>
            </div>
            <Button variant="outline" className="shrink-0" asChild>
              <a href="https://docs.expo.dev" target="_blank" rel="noreferrer">
                Expo dokumentacija
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.55 }}
        className="mt-8 flex items-center justify-center gap-2 text-center"
      >
        <Sparkles className="h-4 w-4 text-lime-300/60" />
        <span className="text-xs text-zinc-600">
          Detaljan vodič je i u <code className="font-mono text-zinc-500">MOBILE.md</code> fajlu u korijenu projekta.
        </span>
      </motion.div>
    </AppShell>
  );
}

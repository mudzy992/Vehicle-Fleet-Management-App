"use client";

import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";
import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-xl bg-white/[0.06]", className)}
      {...props}
    />
  );
}

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root> & { indicatorClassName?: string }
>(({ className, value, indicatorClassName, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn("relative h-1.5 w-full overflow-hidden rounded-full bg-white/[0.08]", className)}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className={cn("h-full w-full flex-1 rounded-full bg-lime-400 transition-all duration-700", indicatorClassName)}
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

function Separator({ className }: { className?: string }) {
  return <div className={cn("h-px w-full bg-white/[0.07]", className)} />;
}

function AvatarCircle({
  initials: text,
  className,
  tone = "lime",
}: {
  initials: string;
  className?: string;
  tone?: "lime" | "sky" | "amber" | "rose" | "violet" | "zinc";
}) {
  const tones: Record<string, string> = {
    lime: "from-lime-400/30 to-emerald-500/20 text-lime-300 border-lime-400/30",
    sky: "from-sky-400/30 to-cyan-500/20 text-sky-300 border-sky-400/30",
    amber: "from-amber-400/30 to-orange-500/20 text-amber-300 border-amber-400/30",
    rose: "from-rose-400/30 to-pink-500/20 text-rose-300 border-rose-400/30",
    violet: "from-violet-400/30 to-purple-500/20 text-violet-300 border-violet-400/30",
    zinc: "from-zinc-400/20 to-zinc-600/20 text-zinc-300 border-zinc-400/20",
  };
  return (
    <div
      className={cn(
        "flex h-10 w-10 shrink-0 items-center justify-center rounded-full border bg-gradient-to-br text-xs font-bold tracking-wider",
        tones[tone],
        className,
      )}
    >
      {text}
    </div>
  );
}

export { Skeleton, Progress, Separator, AvatarCircle };

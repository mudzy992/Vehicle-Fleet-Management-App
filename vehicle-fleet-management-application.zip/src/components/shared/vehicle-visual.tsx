import Image from "next/image";
import { cn } from "@/lib/utils";

const IMG: Record<string, string> = {
  limuzina: "/images/car-sedan.jpg",
  suv: "/images/car-suv.jpg",
  kombi: "/images/car-van.jpg",
  kamion: "/images/car-van.jpg",
};

export function VehicleVisual({
  tip,
  className,
  sizes = "(max-width: 768px) 100vw, 480px",
}: {
  tip: string;
  className?: string;
  sizes?: string;
}) {
  return (
    <div className={cn("relative overflow-hidden bg-zinc-900", className)}>
      <Image
        src={IMG[tip] ?? IMG.limuzina}
        alt="Vozilo"
        fill
        sizes={sizes}
        className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/10 to-transparent" />
    </div>
  );
}

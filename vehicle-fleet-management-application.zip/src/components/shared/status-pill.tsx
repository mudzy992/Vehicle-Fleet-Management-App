import { Badge } from "@/components/ui/badge";
import {
  vehicleStatusLabel,
  driverStatusLabel,
  serviceStatusLabel,
  tripStatusLabel,
  maintenanceStatusLabel,
} from "@/lib/labels";

const tone: Record<string, "ok" | "warning" | "danger" | "info" | "neutral" | "default"> = {
  aktivno: "ok",
  aktivan: "ok",
  servis: "warning",
  neaktivno: "danger",
  neaktivan: "neutral",
  odmor: "info",
  zakazan: "info",
  u_toku: "warning",
  zavrsen: "ok",
  planiran: "info",
  otkazan: "danger",
  predstoji: "warning",
  zakazano: "info",
  uradjeno: "ok",
  isteklo: "danger",
  placeno: "ok",
  neplaceno: "danger",
};

const labels: Record<string, string> = {
  ...vehicleStatusLabel,
  ...driverStatusLabel,
  ...serviceStatusLabel,
  ...tripStatusLabel,
  ...maintenanceStatusLabel,
  placeno: "Plaćeno",
  neplaceno: "Neplaćeno",
};

export function StatusPill({ status }: { status: string }) {
  return <Badge variant={tone[status] ?? "neutral"}>{labels[status] ?? status}</Badge>;
}

"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts";
import { formatNumber } from "@/lib/format";

const tooltipStyle = {
  backgroundColor: "#18181b",
  border: "1px solid rgba(163,230,53,0.25)",
  borderRadius: "12px",
  fontSize: "12px",
  color: "#e4e4e7",
  boxShadow: "0 12px 40px -8px rgba(0,0,0,0.8)",
};

export function CostTrendChart({
  data,
}: {
  data: { mjesec: string; gorivo: number; servisi: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: -8, bottom: 0 }}>
        <defs>
          <linearGradient id="gGorivo" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#a3e635" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#a3e635" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gServisi" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.35} />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
        <XAxis dataKey="mjesec" axisLine={false} tickLine={false} dy={6} />
        <YAxis
          axisLine={false}
          tickLine={false}
          tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
        />
        <Tooltip
          contentStyle={tooltipStyle}
          itemStyle={{ color: "#e4e4e7" }}
          formatter={(value) => [`${formatNumber(Number(value))} RSD`]}
        />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: "#a1a1aa" }} />
        <Area
          type="monotone"
          dataKey="gorivo"
          name="Gorivo"
          stroke="#a3e635"
          strokeWidth={2.5}
          fill="url(#gGorivo)"
        />
        <Area
          type="monotone"
          dataKey="servisi"
          name="Servisi"
          stroke="#38bdf8"
          strokeWidth={2.5}
          fill="url(#gServisi)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function FleetCostChart({
  data,
}: {
  data: { naziv: string; gorivo: number; servisi: number }[];
}) {
  const short = data.map((d) => ({
    ...d,
    naziv: d.naziv.split("—")[0].trim().slice(0, 12),
  }));
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={short} margin={{ top: 10, right: 8, left: -8, bottom: 0 }} barSize={18}>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
        <XAxis dataKey="naziv" axisLine={false} tickLine={false} dy={6} interval={0} angle={-18} textAnchor="end" height={52} />
        <YAxis axisLine={false} tickLine={false} tickFormatter={(v: number) => `${Math.round(v / 1000)}k`} />
        <Tooltip
          contentStyle={tooltipStyle}
          cursor={{ fill: "rgba(163,230,53,0.06)" }}
          formatter={(value) => [`${formatNumber(Number(value))} RSD`]}
        />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: "#a1a1aa" }} />
        <Bar dataKey="gorivo" name="Gorivo" stackId="a" fill="#a3e635" radius={[0, 0, 0, 0]} />
        <Bar dataKey="servisi" name="Servisi" stackId="a" fill="#38bdf8" radius={[8, 8, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function FleetStatusDonut({
  aktivna,
  servis,
  neaktivna,
}: {
  aktivna: number;
  servis: number;
  neaktivna: number;
}) {
  const data = [
    { name: "Aktivna", value: aktivna, color: "#a3e635" },
    { name: "Na servisu", value: servis, color: "#fbbf24" },
    { name: "Neaktivna", value: neaktivna, color: "#52525b" },
  ].filter((d) => d.value > 0);

  return (
    <ResponsiveContainer width="100%" height={210}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          innerRadius={58}
          outerRadius={82}
          paddingAngle={4}
          strokeWidth={0}
          cornerRadius={8}
        >
          {data.map((entry) => (
            <Cell key={entry.name} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip contentStyle={tooltipStyle} itemStyle={{ color: "#e4e4e7" }} />
        <Legend
          iconType="circle"
          iconSize={8}
          layout="vertical"
          align="right"
          verticalAlign="middle"
          wrapperStyle={{ fontSize: 12, color: "#a1a1aa" }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

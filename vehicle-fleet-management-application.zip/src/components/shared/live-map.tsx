"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Gauge, MapPin, Satellite } from "lucide-react";

export type MapVehicle = {
  vehicleId: number;
  vozilo: string;
  oznaka: string;
  status: string;
  lat: string | number;
  lng: string | number;
  adresa: string | null;
  brzina: number;
};

export type MapTrail = {
  vehicleId: number;
  lat: string | number;
  lng: string | number;
};

type Projected = { x: number; y: number };

const COLORS: Record<string, string> = {
  moving: "#a3e635",
  parked: "#71717a",
  servis: "#fbbf24",
};

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function LiveMap({
  latest,
  trails,
  className,
  interactive = true,
}: {
  latest: MapVehicle[];
  trails: MapTrail[];
  className?: string;
  interactive?: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState<number | null>(latest[0]?.vehicleId ?? null);
  const [hoverId, setHoverId] = useState<number | null>(null);
  const dataRef = useRef({ latest, trails, selectedId, hoverId });
  dataRef.current = { latest, trails, selectedId, hoverId };

  const project = useCallback(
    (lat: number, lng: number, w: number, h: number): Projected => {
      const lats = latest.map((v) => Number(v.lat));
      const lngs = latest.map((v) => Number(v.lng));
      const minLat = Math.min(...lats, 42.2) - 0.35;
      const maxLat = Math.max(...lats, 46.1) + 0.35;
      const minLng = Math.min(...lngs, 15.7) - 0.5;
      const maxLng = Math.max(...lngs, 22.1) + 0.5;
      const x = ((lng - minLng) / (maxLng - minLng)) * (w * 0.86) + w * 0.07;
      const y = (1 - (lat - minLat) / (maxLat - minLat)) * (h * 0.82) + h * 0.09;
      return { x, y };
    },
    [latest],
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const rng = mulberry32(20240101);
    const roadArt = Array.from({ length: 26 }, () => ({
      x1: rng(), y1: rng(), x2: rng(), y2: rng(),
      cx: rng(), cy: rng(), w: rng() > 0.7 ? 1.6 : 0.8,
    }));
    const blocks = Array.from({ length: 90 }, () => ({
      x: rng(), y: rng(), w: 0.012 + rng() * 0.03, h: 0.006 + rng() * 0.02, a: 0.02 + rng() * 0.05,
    }));

    const draw = (t: number) => {
      const { latest: lv, trails: tv, hoverId: hv, selectedId: sv } = dataRef.current;
      ctx.clearRect(0, 0, w, h);

      // Pozadina
      const bg = ctx.createRadialGradient(w * 0.5, h * 0.42, 60, w * 0.5, h * 0.5, Math.max(w, h));
      bg.addColorStop(0, "#0b0e13");
      bg.addColorStop(1, "#07080b");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Gradski blokovi
      for (const b of blocks) {
        ctx.fillStyle = `rgba(228,228,231,${b.a})`;
        ctx.fillRect(b.x * w, b.y * h, b.w * w, b.h * h);
      }

      // Putevi
      for (const r of roadArt) {
        ctx.beginPath();
        ctx.moveTo(r.x1 * w, r.y1 * h);
        ctx.quadraticCurveTo(r.cx * w, r.cy * h, r.x2 * w, r.y2 * h);
        ctx.strokeStyle = "rgba(163,230,53,0.055)";
        ctx.lineWidth = r.w;
        ctx.stroke();
      }

      // Tragovi vozila
      const byVehicle = new Map<number, MapTrail[]>();
      for (const tr of tv) {
        const arr = byVehicle.get(tr.vehicleId) ?? [];
        arr.push(tr);
        byVehicle.set(tr.vehicleId, arr);
      }
      for (const v of lv) {
        const list = byVehicle.get(v.vehicleId);
        if (!list || list.length < 2) continue;
        const moving = v.status === "aktivno" && v.brzina > 0;
        if (!moving) continue;
        ctx.beginPath();
        list.forEach((p, i) => {
          const pt = project(Number(p.lat), Number(p.lng), w, h);
          if (i === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        });
        ctx.strokeStyle = "rgba(163,230,53,0.28)";
        ctx.lineWidth = 1.6;
        ctx.setLineDash([5, 6]);
        ctx.lineDashOffset = -t / 60;
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Vozila
      for (const v of lv) {
        const p = project(Number(v.lat), Number(v.lng), w, h);
        const drift = v.status === "aktivno" && v.brzina > 0 ? 2.4 : 0.7;
        const dx = Math.sin(t / 900 + v.vehicleId * 1.7) * drift;
        const dy = Math.cos(t / 1100 + v.vehicleId * 2.3) * drift;
        const x = p.x + dx;
        const y = p.y + dy;

        const moving = v.status === "aktivno" && v.brzina > 0;
        const key = v.status === "servis" ? "servis" : moving ? "moving" : "parked";
        const color = COLORS[key];
        const active = sv === v.vehicleId || hv === v.vehicleId;

        // Pulse ring
        if (moving || active) {
          const phase = ((t / 1400 + v.vehicleId * 0.37) % 1);
          ctx.beginPath();
          ctx.arc(x, y, 8 + phase * 22, 0, Math.PI * 2);
          ctx.strokeStyle = color + Math.round((1 - phase) * 90).toString(16).padStart(2, "0");
          ctx.lineWidth = 1.4;
          ctx.stroke();
        }

        // Glow
        const glow = ctx.createRadialGradient(x, y, 0, x, y, active ? 26 : 16);
        glow.addColorStop(0, color + "55");
        glow.addColorStop(1, color + "00");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(x, y, active ? 26 : 16, 0, Math.PI * 2);
        ctx.fill();

        // Core dot
        ctx.beginPath();
        ctx.arc(x, y, active ? 5.5 : 4, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
        ctx.lineWidth = 1.6;
        ctx.strokeStyle = "rgba(7,8,11,0.9)";
        ctx.stroke();

        // Label
        if (active) {
          ctx.font = "600 11px 'JetBrains Mono', monospace";
          const text = v.oznaka;
          const tw = ctx.measureText(text).width;
          ctx.fillStyle = "rgba(9,10,13,0.88)";
          ctx.beginPath();
          ctx.roundRect(x - tw / 2 - 8, y - 34, tw + 16, 20, 6);
          ctx.fill();
          ctx.strokeStyle = color + "66";
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = "#f4f4f5";
          ctx.fillText(text, x - tw / 2, y - 20);
        }
      }

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    const onMove = (e: MouseEvent) => {
      if (!interactive) return;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      let found: number | null = null;
      for (const v of dataRef.current.latest) {
        const p = project(Number(v.lat), Number(v.lng), rect.width, rect.height);
        if (Math.hypot(p.x - mx, p.y - my) < 18) {
          found = v.vehicleId;
          break;
        }
      }
      setHoverId(found);
      canvas.style.cursor = found ? "pointer" : "default";
    };
    const onClick = () => {
      if (hoverId != null) setSelectedId(hoverId);
    };
    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("click", onClick);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("click", onClick);
    };
  }, [project, interactive, hoverId]);

  const selected = latest.find((v) => v.vehicleId === selectedId) ?? latest[0];

  return (
    <div ref={wrapRef} className={cn("relative overflow-hidden rounded-2xl", className)}>
      <canvas ref={canvasRef} className="absolute inset-0" />

      {/* Header chip */}
      <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-xl border border-white/10 bg-zinc-950/80 px-3 py-2 backdrop-blur-md">
        <Satellite className="h-3.5 w-3.5 text-lime-300" />
        <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-zinc-300">
          GPS telemetrija • {latest.length} vozila
        </span>
      </div>

      {/* Vehicle chips */}
      {interactive && (
        <div className="absolute right-4 top-4 hidden max-w-[220px] flex-col gap-1.5 md:flex">
          {latest.map((v) => {
            const active = selectedId === v.vehicleId;
            const moving = v.status === "aktivno" && v.brzina > 0;
            return (
              <button
                key={v.vehicleId}
                onClick={() => setSelectedId(v.vehicleId)}
                className={cn(
                  "flex items-center gap-2.5 rounded-xl border px-3 py-2 text-left backdrop-blur-md transition-all cursor-pointer",
                  active
                    ? "border-lime-400/50 bg-lime-400/10"
                    : "border-white/10 bg-zinc-950/75 hover:border-white/25",
                )}
              >
                <span
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{
                    backgroundColor:
                      v.status === "servis" ? "#fbbf24" : moving ? "#a3e635" : "#71717a",
                    boxShadow:
                      moving || active ? "0 0 10px currentColor" : undefined,
                  }}
                />
                <span className="min-w-0">
                  <span className="block truncate text-xs font-medium text-zinc-200">{v.vozilo}</span>
                  <span className="block font-mono text-[10px] text-zinc-500">
                    {v.oznaka} • {v.brzina > 0 ? `${v.brzina} km/h` : "parkirano"}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Selected details */}
      {selected && interactive && (
        <div className="absolute bottom-4 left-4 max-w-xs rounded-xl border border-white/10 bg-zinc-950/85 p-4 backdrop-blur-md">
          <div className="mb-1 flex items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-lime-300">
              {selected.oznaka}
            </span>
          </div>
          <div className="text-sm font-semibold text-white">{selected.vozilo}</div>
          <div className="mt-2 space-y-1.5 text-xs text-zinc-400">
            <div className="flex items-center gap-2">
              <MapPin className="h-3.5 w-3.5 text-zinc-500" />
              <span className="truncate">{selected.adresa ?? "Nepoznata adresa"}</span>
            </div>
            <div className="flex items-center gap-2">
              <Gauge className="h-3.5 w-3.5 text-zinc-500" />
              {selected.brzina > 0 ? `${selected.brzina} km/h — u pokretu` : "Parkirano"}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import { apiGet } from "@/lib/api";

export function useApi<T>(url: string, refreshMs?: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const result = await apiGet<T>(url);
      setData(result);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Greška");
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    reload();
    if (refreshMs) {
      const id = setInterval(() => reload(true), refreshMs);
      return () => clearInterval(id);
    }
  }, [reload, refreshMs]);

  return { data, error, loading, reload };
}

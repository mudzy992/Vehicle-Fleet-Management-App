"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Car,
  Users,
  Wrench,
  FileCheck2,
  Route,
  MapPin,
  Smartphone,
  Gauge,
  ArrowLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "Pregled", icon: LayoutDashboard },
  { href: "/vozila", label: "Vozila", icon: Car },
  { href: "/vozaci", label: "Vozači", icon: Users },
  { href: "/servisi", label: "Servisi", icon: Wrench },
  { href: "/registracije", label: "Registracije", icon: FileCheck2 },
  { href: "/putni-nalozi", label: "Putni nalozi", icon: Route },
  { href: "/lokacije", label: "Lokacije", icon: MapPin },
  { href: "/mobilna-aplikacija", label: "Mobilna app", icon: Smartphone },
];

function LiveClock() {
  const [time, setTime] = useState("");
  useEffect(() => {
    const tick = () =>
      setTime(
        new Date().toLocaleTimeString("sr-Latn-RS", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
      );
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="font-mono text-xs tabular-nums text-zinc-500 tracking-widest">
      {time}
    </span>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-[#07080b] text-zinc-200">
      {/* Sidebar — desktop */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-white/[0.06] bg-zinc-950/80 backdrop-blur-xl lg:flex">
        <Link href="/" className="flex items-center gap-3 px-6 py-6 group">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-lime-400 text-zinc-950 shadow-[0_0_28px_-6px_rgba(163,230,53,0.8)] group-hover:shadow-[0_0_36px_-4px_rgba(163,230,53,1)] transition-shadow">
            <Gauge className="h-5 w-5" strokeWidth={2.4} />
          </div>
          <div>
            <div className="text-lg font-bold tracking-tight text-white leading-none">FLOTA</div>
            <div className="text-[10px] font-mono uppercase tracking-[0.22em] text-zinc-500">
              Fleet OS
            </div>
          </div>
        </Link>

        <nav className="flex-1 space-y-1 px-3 py-4 overflow-y-auto">
          {NAV.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "relative flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                  active ? "text-zinc-950" : "text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.05]",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="nav-active"
                    className="absolute inset-0 rounded-xl bg-lime-400 shadow-[0_0_24px_-6px_rgba(163,230,53,0.7)]"
                    transition={{ type: "spring", stiffness: 420, damping: 32 }}
                  />
                )}
                <item.icon className="relative z-10 h-[18px] w-[18px]" strokeWidth={2} />
                <span className="relative z-10">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-white/[0.06] p-4">
          <Link
            href="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-zinc-500 hover:text-lime-300 transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Početna stranica
          </Link>
          <div className="mt-2 flex items-center gap-2 px-3">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 animate-ping-dot" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-500">
              Sistem aktivan
            </span>
          </div>
        </div>
      </aside>

      {/* Top bar */}
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/[0.06] bg-[#07080b]/80 px-4 backdrop-blur-xl lg:pl-[16.5rem] lg:pr-8">
        <div className="flex items-center gap-3 lg:hidden">
          <Link href="/" className="flex h-9 w-9 items-center justify-center rounded-xl bg-lime-400 text-zinc-950">
            <Gauge className="h-5 w-5" />
          </Link>
          <span className="font-bold text-white">FLOTA</span>
        </div>
        <div className="hidden lg:block text-sm text-zinc-500">
          Kontrolni centar voznog parka
        </div>
        <div className="flex items-center gap-4">
          <LiveClock />
          <div className="flex h-9 items-center gap-2 rounded-xl border border-white/[0.08] bg-zinc-900/70 px-3">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-lime-400 animate-ping-dot" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-lime-400" />
            </span>
            <span className="text-xs font-medium text-zinc-300">GPS uživo</span>
          </div>
        </div>
      </header>

      {/* Mobile nav */}
      <nav className="sticky top-16 z-30 flex gap-1 overflow-x-auto border-b border-white/[0.06] bg-[#07080b]/90 px-3 py-2 backdrop-blur-xl lg:hidden">
        {NAV.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium",
                active ? "bg-lime-400 text-zinc-950" : "text-zinc-400 hover:text-zinc-100",
              )}
            >
              <item.icon className="h-3.5 w-3.5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <main className="px-4 py-6 sm:px-6 lg:pl-[17.5rem] lg:pr-8 lg:py-8">{children}</main>
    </div>
  );
}

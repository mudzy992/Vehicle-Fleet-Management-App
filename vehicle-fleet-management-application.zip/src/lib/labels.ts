export const vehicleStatusLabel: Record<string, string> = {
  aktivno: "Aktivno",
  servis: "Na servisu",
  neaktivno: "Neaktivno",
};

export const driverStatusLabel: Record<string, string> = {
  aktivan: "Aktivan",
  odmor: "Odsutan",
  neaktivan: "Neaktivan",
};

export const serviceTypeLabel: Record<string, string> = {
  mali_servis: "Mali servis",
  veliki_servis: "Veliki servis",
  popravka: "Popravka",
  gume: "Gume",
  registracija_radovi: "Radovi za registraciju",
  ostalo: "Ostalo",
};

export const serviceStatusLabel: Record<string, string> = {
  zakazan: "Zakazan",
  u_toku: "U toku",
  zavrsen: "Završen",
};

export const tripStatusLabel: Record<string, string> = {
  planiran: "Planiran",
  u_toku: "U toku",
  zavrsen: "Završen",
  otkazan: "Otkazan",
};

export const maintenanceStatusLabel: Record<string, string> = {
  predstoji: "Predstoji",
  zakazano: "Zakazano",
  uradjeno: "Urađeno",
  isteklo: "Isteklo",
};

export const fuelTypeLabel: Record<string, string> = {
  dizel: "Dizel",
  benzin: "Benzin",
  hibrid: "Hibrid",
  elektricno: "Električno",
  gas: "Gas",
};

export const vehicleTypeLabel: Record<string, string> = {
  limuzina: "Limuzina",
  suv: "SUV",
  kombi: "Kombi",
  kamion: "Kamion",
};

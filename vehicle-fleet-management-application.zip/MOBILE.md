# FLOTA Mobile — Expo (React Native) priprema

Mobilna aplikacija koristi **isti backend** kao web (REST API + PostgreSQL).
Nije potreban zaseban server: Expo app pogađa iste rute koje vidiš u pregledaču.

## 1. Kreiraj projekt

```bash
npx create-expo-app@latest flota-mobile
cd flota-mobile
npx expo install expo-notifications expo-location expo-router
```

## 2. Konektuj se na backend

`.env` u Expo projektu:

```bash
EXPO_PUBLIC_API_URL=https://flota.tvojafirma.rs   # ili http://<lokalna-ip>:3000 u razvoju
```

`lib/api.ts` (spreman klijent — kopiraj as-is):

```ts
const API_URL = process.env.EXPO_PUBLIC_API_URL;

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${path}`);
  return res.json();
}

export const getVehicles = () => api<Vehicle[]>("/api/vehicles");
export const getTrips = () => api<Trip[]>("/api/trips");
export const getLocations = () => api<LocationFeed>("/api/locations");
export const startTrip = (id: number) =>
  api<Trip>(`/api/trips/${id}`, { method: "PATCH", body: JSON.stringify({ status: "u_toku" }) });
export const finishTrip = (id: number, km: number) =>
  api<Trip>(`/api/trips/${id}`, {
    method: "PATCH",
    body: JSON.stringify({ status: "zavrsen", predjenoKm: km }),
  });
```

Tipove (`Vehicle`, `Trip`, …) preuzmi iz `src/db/schema.ts` — to je ugovor sa bazom.

## 3. Struktura ekrana (preporuka)

```
app/
├── (tabs)/
│   ├── index.tsx      # Početna: aktivan nalog + KPI sa /api/dashboard
│   ├── vozila.tsx     # /api/vehicles
│   ├── nalozi.tsx     # /api/trips + akcije pokreni/završi
│   └── profil.tsx     # karton vozača
└── nalog/[id].tsx
```

## 4. Dostupne rute

| Metoda | Ruta | Opis |
|---|---|---|
| GET | `/api/dashboard` | KPI, trendovi troškova, alerti, GPS sažetak |
| GET/POST | `/api/vehicles` | Lista / dodavanje vozila |
| GET/PATCH/DELETE | `/api/vehicles/:id` | Detalji, izmjena, brisanje |
| GET/POST | `/api/drivers` | Vozači |
| GET/POST | `/api/trips` | Putni nalozi |
| PATCH | `/api/trips/:id` | Statusi + prijava kilometraže |
| GET/POST | `/api/services` | Servisi |
| GET/POST | `/api/registrations` | Registracije |
| GET | `/api/locations` | GPS pozicije + tragovi |
| GET | `/api/fuel-logs` | Gorivo |
| GET | `/api/maintenance` | Plan održavanja (PATCH za status) |

## 5. Push notifikacije

1. `expo-notifications` + EAS projekt ID.
2. Token vozača čuvaj u tabeli `drivers` (dodaj kolonu `push_token`).
3. Backend job (cron) šalje obavještenja za registracije koje ističu ≤ 30 dana — podatak već vraća `/api/dashboard` → `alerti.registracije`.

## 6. Produkcija

- Dodaj `Authorization: Bearer <token>` middleware na API rute prije objave.
- EAS Build profili: `development`, `preview`, `production`.
- Rate limiting za `/api/locations` (vozači pingaju često).
- Sentry za crash reporting: `npx expo install sentry-expo`.
